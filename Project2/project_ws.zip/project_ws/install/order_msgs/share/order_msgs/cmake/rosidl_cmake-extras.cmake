# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(order_msgs_IDL_FILES "srv/OrderService.idl")
set(order_msgs_INTERFACE_FILES "srv/OrderService.srv;srv/OrderService_Request.msg;srv/OrderService_Response.msg")
