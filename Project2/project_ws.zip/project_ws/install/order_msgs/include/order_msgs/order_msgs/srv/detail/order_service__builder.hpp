// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from order_msgs:srv/OrderService.idl
// generated code does not contain a copyright notice

#ifndef ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__BUILDER_HPP_
#define ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "order_msgs/srv/detail/order_service__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace order_msgs
{

namespace srv
{

namespace builder
{

class Init_OrderService_Request_order_message
{
public:
  Init_OrderService_Request_order_message()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::order_msgs::srv::OrderService_Request order_message(::order_msgs::srv::OrderService_Request::_order_message_type arg)
  {
    msg_.order_message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::order_msgs::srv::OrderService_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::order_msgs::srv::OrderService_Request>()
{
  return order_msgs::srv::builder::Init_OrderService_Request_order_message();
}

}  // namespace order_msgs


namespace order_msgs
{

namespace srv
{

namespace builder
{

class Init_OrderService_Response_response_message
{
public:
  explicit Init_OrderService_Response_response_message(::order_msgs::srv::OrderService_Response & msg)
  : msg_(msg)
  {}
  ::order_msgs::srv::OrderService_Response response_message(::order_msgs::srv::OrderService_Response::_response_message_type arg)
  {
    msg_.response_message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::order_msgs::srv::OrderService_Response msg_;
};

class Init_OrderService_Response_success
{
public:
  Init_OrderService_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_OrderService_Response_response_message success(::order_msgs::srv::OrderService_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_OrderService_Response_response_message(msg_);
  }

private:
  ::order_msgs::srv::OrderService_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::order_msgs::srv::OrderService_Response>()
{
  return order_msgs::srv::builder::Init_OrderService_Response_success();
}

}  // namespace order_msgs

#endif  // ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__BUILDER_HPP_
