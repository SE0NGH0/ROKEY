// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from order_msgs:srv/OrderService.idl
// generated code does not contain a copyright notice

#ifndef ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__STRUCT_H_
#define ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'order_message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/OrderService in the package order_msgs.
typedef struct order_msgs__srv__OrderService_Request
{
  rosidl_runtime_c__String order_message;
} order_msgs__srv__OrderService_Request;

// Struct for a sequence of order_msgs__srv__OrderService_Request.
typedef struct order_msgs__srv__OrderService_Request__Sequence
{
  order_msgs__srv__OrderService_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} order_msgs__srv__OrderService_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'response_message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/OrderService in the package order_msgs.
typedef struct order_msgs__srv__OrderService_Response
{
  bool success;
  rosidl_runtime_c__String response_message;
} order_msgs__srv__OrderService_Response;

// Struct for a sequence of order_msgs__srv__OrderService_Response.
typedef struct order_msgs__srv__OrderService_Response__Sequence
{
  order_msgs__srv__OrderService_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} order_msgs__srv__OrderService_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ORDER_MSGS__SRV__DETAIL__ORDER_SERVICE__STRUCT_H_
