// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ORDER_MSGS__SRV__ORDER_SERVICE_HPP_
#define ORDER_MSGS__SRV__ORDER_SERVICE_HPP_

#include "order_msgs/srv/detail/order_service__struct.hpp"
#include "order_msgs/srv/detail/order_service__builder.hpp"
#include "order_msgs/srv/detail/order_service__traits.hpp"

#endif  // ORDER_MSGS__SRV__ORDER_SERVICE_HPP_
