from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'turtlebot3_gui'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='moon0',
    maintainer_email='moon0@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'table = turtlebot3_gui.table:main',
            'kitchen = turtlebot3_gui.kitchen:main',
            'robot = turtlebot3_gui.robot:main'
        ],
    },
)
