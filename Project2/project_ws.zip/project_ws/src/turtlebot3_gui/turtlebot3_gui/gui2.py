import sys
import threading
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from order_msgs.srv import OrderService
from std_msgs.msg import String
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QListWidget, QMessageBox, QComboBox
from PyQt5.QtCore import pyqtSignal, QObject

class Signals(QObject):
    order_signal = pyqtSignal(str, int)
    status_signal = pyqtSignal(str, int)
    table_popup_signal = pyqtSignal(str, int)

signals = Signals()

class KitchenOrderDisplay(Node, QWidget):
    def __init__(self):
        Node.__init__(self, 'kitchen_order_display')
        QWidget.__init__(self)
        self.initUI()

        # ROS2 service to receive orders
        self.service = self.create_service(OrderService, 'submit_order_service', self.receive_order_callback)

        # ROS2 publisher to publish order status
        self.status_publishers = {}
        for i in range(1, 10):  # Create publishers for each table
            self.status_publishers[i] = self.create_publisher(String, f'order_status_table_{i}', 10)

        # ROS2 subscriber to receive payment completion updates
        self.payment_subscriber = self.create_subscription(String, 'payment_completion', self.receive_payment_callback, 10)

        # 결제 상태를 관리하는 딕셔너리
        self.payment_status = {}

        # 각 테이블의 현재 상태를 관리하는 딕셔너리
        self.current_status = {}

        # 상태 단계 리스트 (정해진 순서)
        self.status_sequence = ["Order Accepted", "Cooking", "Cooking Completed", "Delivery In Progress", "Delivery Completed"]

        # Connect to signals for table status updates
        signals.status_signal.connect(self.update_status_from_signal)

    def initUI(self):
        # Main layout
        layout = QVBoxLayout()

        # Label for kitchen orders
        self.orders_label = QLabel("Kitchen Orders:")
        layout.addWidget(self.orders_label)

        # List to display orders
        self.orders_list = QListWidget()
        layout.addWidget(self.orders_list)

        # Accept and Reject buttons
        self.accept_button = QPushButton("Accept Order")
        self.accept_button.clicked.connect(self.acceptOrder)
        layout.addWidget(self.accept_button)

        self.reject_button = QPushButton("Reject Order")
        self.reject_button.clicked.connect(self.rejectOrder)
        layout.addWidget(self.reject_button)

        # Status update combo box
        self.status_combobox = QComboBox()
        self.status_combobox.addItems(["Cooking", "Cooking Completed", "Delivery In Progress", "Delivery Completed"])
        layout.addWidget(self.status_combobox)

        # Button to update order status
        self.update_status_button = QPushButton("Update Status")
        self.update_status_button.clicked.connect(self.updateOrderStatus)
        layout.addWidget(self.update_status_button)

        self.setLayout(layout)
        self.setWindowTitle('Kitchen Order Display')
        self.show()

    def receive_order_callback(self, request, response):
        # Add the received order message to the orders list
        self.orders_list.addItem(request.order_message)
        self.get_logger().info(f'Received Order:\n{request.order_message}')
        response.success = True
        response.response_message = 'Order received successfully'
        return response

    def acceptOrder(self):
        current_item = self.orders_list.currentItem()
        if current_item:
            order_message = current_item.text()
            QMessageBox.information(self, "Order Accepted", f"Order accepted: {order_message}")

            # 주문 정보 발행 (메뉴 정보와 총 가격 포함)
            order_details_msg = String()
            order_details_msg.data = f"Order: {order_message}"
            self.status_publishers[int(order_message.split(' ')[1])].publish(order_details_msg)
            self.get_logger().info(f'Published Order Details: {order_details_msg.data}')
            
            # 상태 정보 발행 (주문이 승인되었음을 알림)
            self.publish_status(order_message, "Order Accepted")

            # 결제 상태를 False로 초기화
            table_number = int(order_message.split(' ')[1])
            self.payment_status[table_number] = False
        else:
            QMessageBox.warning(self, "No Selection", "Please select an order to accept.")


    def makePayment(self, table_number):
        # 결제 상태를 True로 설정
        if table_number in self.payment_status:
            self.payment_status[table_number] = True
            self.get_logger().info(f'Payment received for table {table_number}')
        else:
            self.get_logger().warning(f'Tried to make payment for non-existent order for table {table_number}')
    def publish_order_details(self, order_message):
        table_number = int(order_message.split(' ')[1])
        order_details_msg = String()
        order_details_msg.data = order_message
        if table_number in self.status_publishers:
            self.status_publishers[table_number].publish(order_details_msg)
            self.get_logger().info(f'Published Order Details to table {table_number}: {order_details_msg.data}')

    def rejectOrder(self):
        current_item = self.orders_list.currentItem()
        if current_item:
            order_message = current_item.text()
            QMessageBox.information(self, "Order Rejected", f"Order rejected: {order_message}")
            self.orders_list.takeItem(self.orders_list.currentRow())
            
            # 상태만 발행하고 주문 정보는 발행하지 않음
            self.publish_status(order_message, "Order Rejected")
        else:
            QMessageBox.warning(self, "No Selection", "Please select an order to reject.")

    def updateOrderStatus(self):
        current_item = self.orders_list.currentItem()
        if current_item:
            order_message = current_item.text()
            table_number = int(order_message.split(' ')[1])

            # 결제 여부 확인
            if not self.payment_status.get(table_number, False):
                QMessageBox.warning(self, "Payment Required", "Cannot update status until payment is made.")
                return

            # 상태 단계 관리: 현재 상태가 있어야 다음 상태로 넘어갈 수 있음
            current_status = self.current_status.get(table_number, "Order Accepted")
            next_status = self.status_combobox.currentText()

            try:
                # 상태 단계 리스트에서 현재 상태와 다음 상태의 인덱스를 확인하여 순차적 업데이트만 허용
                current_index = self.status_sequence.index(current_status)
                next_index = self.status_sequence.index(next_status)

                # 현재 상태의 다음 상태로만 전환을 허용
                if next_index == current_index + 1:
                    # 상태 업데이트 가능
                    QMessageBox.information(self, "Status Updated", f"Order status updated to: {next_status}")
                    self.publish_status(order_message, f"{next_status}")
                    # 상태 업데이트
                    self.current_status[table_number] = next_status
                    self.get_logger().info(f"Order status for table {table_number} updated to: {next_status}")

                    # 만약 상태가 "Delivery Completed"라면 주문 정보를 삭제
                    if next_status == "Delivery Completed":
                        self.orders_list.takeItem(self.orders_list.currentRow())
                        self.get_logger().info(f"Order for table {table_number} has been completed and removed from the list.")
                elif next_index <= current_index:
                    QMessageBox.warning(self, "Invalid Status Transition", "You must move to the next sequential status.")
                else:
                    QMessageBox.warning(self, "Invalid Status Transition", "Skipping statuses is not allowed.")
            except ValueError as e:
                self.get_logger().error(f"Status transition error: {e}")
                QMessageBox.warning(self, "Invalid Status", f"Selected status is not valid: {next_status}")
        else:
            QMessageBox.warning(self, "No Selection", "Please select an order to update status.")

    def publish_status(self, order_message, status):
        # 테이블 번호를 주문 메시지에서 추출하여 올바른 토픽에 상태를 발행
        table_number = int(order_message.split(' ')[1])  # 'Table 5 Order'에서 테이블 번호 추출
        status_message = String()

        # 상태 메시지에 주문 정보가 아닌 테이블 번호와 상태만 포함
        status_message.data = f"Table {table_number} - Status: {status}"
        
        if table_number in self.status_publishers:
            self.status_publishers[table_number].publish(status_message)
            self.get_logger().info(f'Published Order Status to table {table_number}: {status_message.data}')
            signals.status_signal.emit(status, table_number)

    def receive_payment_callback(self, msg):
        # 결제 완료 메시지를 수신하여 결제 상태를 True로 설정
        if "Payment completed for Table" in msg.data:
            table_number = int(msg.data.split(' ')[-1])
            self.payment_status[table_number] = True
            self.get_logger().info(f'Received payment completion for table {table_number}')

    def update_status_from_signal(self, status, table_number):
        # Update the status in the orders list based on the table number
        for i in range(self.orders_list.count()):
            item_text = self.orders_list.item(i).text()
            if f"Table {table_number}" in item_text:
                self.orders_list.item(i).setText(f"Table {table_number} - Status: {status}")
                break

def main(args=None):
    rclpy.init(args=args)
    app = QApplication(sys.argv)
    kitchen_display = KitchenOrderDisplay()

    # Run ROS2 spin in a separate thread to avoid blocking the GUI
    ros_thread = threading.Thread(target=rclpy.spin, args=(kitchen_display,), daemon=True)
    ros_thread.start()

    sys.exit(app.exec_())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
