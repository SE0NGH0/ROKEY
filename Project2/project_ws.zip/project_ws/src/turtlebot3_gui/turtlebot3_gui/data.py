import os
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from datetime import datetime
from collections import Counter
from PyQt5.QtWidgets import (
    QApplication, QVBoxLayout, QMainWindow, QWidget, QScrollArea, QMessageBox
)


class StatsWindow(QMainWindow):
    def __init__(self, database_path):
        super().__init__()
        self.database_path = database_path
        self.setWindowTitle("Statistics Dashboard")
        self.setGeometry(100, 100, 800, 600)  # GUI 창 크기 설정

        # 메인 위젯 설정
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 스크롤 영역 추가
        scroll_area = QScrollArea()
        scroll_area_widget = QWidget()
        scroll_layout = QVBoxLayout()

        # 데이터 처리 및 그래프 생성
        if not os.path.exists(self.database_path):
            QMessageBox.critical(self, "Error", "Database file not found!")
            return

        conn = sqlite3.connect(self.database_path)
        query = "SELECT * FROM orders"
        df = pd.read_sql_query(query, conn)
        conn.close()

        if df.empty:
            QMessageBox.warning(self, "No Data", "No data available in the database.")
            return

        df['date'] = pd.to_datetime(df['date'])
        current_year = datetime.now().year
        df = df[df['date'].dt.year == current_year]

        if df.empty:
            QMessageBox.warning(self, "No Data", f"No data available for the year {current_year}.")
            return

        # 메뉴별 판매 빈도 계산
        menu_counts = Counter()
        for order in df['order_details']:
            lines = order.split("\n")
            for line in lines:
                if ':' in line and line.count(": ") == 1 and 'Total Price' not in line:
                    try:
                        menu, count = line.split(": ")
                        menu_counts[menu.strip()] += int(count.strip())
                    except ValueError:
                        continue

        # 날짜별 총 판매 금액 계산
        def extract_total_price(order_details):
            lines = order_details.split("\n")
            for line in lines:
                if "Total Price:" in line:
                    try:
                        return float(line.split("$")[-1])
                    except ValueError:
                        continue
            return 0

        df['total_price'] = df['order_details'].apply(extract_total_price)
        daily_sales = df.groupby(df['date'].dt.date)['total_price'].sum()

        # 그래프 1: 메뉴별 판매 빈도
        fig1, ax1 = plt.subplots(figsize=(6, 4))  # 그래프 크기 조정
        ax1.bar(menu_counts.keys(), menu_counts.values(), color='skyblue')
        ax1.set_title(f"Menu Sales Counts ({current_year})")
        ax1.set_xlabel("Menu Item")
        ax1.set_ylabel("Number of Items Sold")
        ax1.tick_params(axis='x', rotation=45)
        canvas1 = FigureCanvas(fig1)
        scroll_layout.addWidget(canvas1)

        # 그래프 2: 날짜별 총 판매 금액
        fig2, ax2 = plt.subplots(figsize=(6, 4))  # 그래프 크기 조정
        ax2.bar(daily_sales.index, daily_sales.values, color='orange')
        ax2.set_title(f"Daily Total Sales ({current_year})")
        ax2.set_xlabel("Date")
        ax2.set_ylabel("Total Sales ($)")
        ax2.tick_params(axis='x', rotation=45)
        canvas2 = FigureCanvas(fig2)
        scroll_layout.addWidget(canvas2)

        # 스크롤 영역에 그래프 추가
        scroll_area_widget.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_area_widget)
        scroll_area.setWidgetResizable(True)

        # 중앙 레이아웃에 스크롤 영역 추가
        main_layout = QVBoxLayout(central_widget)
        main_layout.addWidget(scroll_area)


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    database_path = "/home/parkseongho/project_ws/database.db"
    stats_window = StatsWindow(database_path)
    stats_window.show()
    sys.exit(app.exec_())
