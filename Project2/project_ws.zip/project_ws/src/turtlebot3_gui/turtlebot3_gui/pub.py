import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class HelloWorldPublisher(Node):
    def __init__(self):
        super().__init__('hello_world_publisher')
        self.publisher_ = self.create_publisher(String, 'hello_world_topic', 10)
        timer_period = 1.0  # 초 단위, 1초마다 메시지 퍼블리시
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def timer_callback(self):
        msg = String()
        msg.data = 'hello world'
        self.publisher_.publish(msg)
        self.get_logger().info('I said: "%s"' % msg.data)

def main(args=None):
    rclpy.init(args=args)
    publisher = HelloWorldPublisher()
    rclpy.spin(publisher)
    publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()