import pyttsx3

def list_voices():
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    for idx, voice in enumerate(voices):
        print(f"Voice {idx}:")
        print(f"  Name: {voice.name}")
        print(f"  ID: {voice.id}")
        print(f"  Gender: {'Female' if 'female' in voice.name.lower() else 'Male'}")
        print(f"  Language: {voice.languages}\n")

list_voices()
