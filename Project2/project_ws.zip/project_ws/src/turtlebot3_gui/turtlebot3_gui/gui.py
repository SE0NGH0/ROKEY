import sys
import threading
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from order_msgs.srv import OrderService
from std_msgs.msg import String
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QGridLayout, QHBoxLayout, QInputDialog, QListWidget, QMessageBox
from PyQt5.QtGui import QPixmap

class TableOrderDisplay(Node, QWidget):
    def __init__(self, table_number):
        Node.__init__(self, f'table_order_display_{table_number}')
        QWidget.__init__(self)
        self.table_number = table_number
        self.client_ = self.create_client(OrderService, 'submit_order_service')
        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for service to become available...')
        
        # ROS2 publisher to publish payment completion information
        self.payment_publisher = self.create_publisher(String, 'payment_completion', 10)

        # ROS2 subscriber to receive order status updates for this table
        self.status_subscriber = self.create_subscription(String, f'order_status_table_{self.table_number}', self.receive_status_callback, 10)

        # 초기화 메서드 호출
        self.initUI()

    def initUI(self):
        # Dictionary to store order counts for each table
        self.order_counts = {}
        self.total_price = 0.0

        # Main layout
        layout = QVBoxLayout()

        # Menu items (name, price, image path)
        self.menu_items = [
            ("Burger", 5.99, "src/turtlebot3_gui/turtlebot3_gui/images/hamburger.png"),
            ("Pizza", 8.99, "src/turtlebot3_gui/turtlebot3_gui/images/pizza.png"),
            ("Salad", 4.99, "src/turtlebot3_gui/turtlebot3_gui/images/salad.png"),
            ("Pasta", 7.49, "src/turtlebot3_gui/turtlebot3_gui/images/pasta.png"),
        ]

        # Create menu buttons with images
        self.menu_buttons = QGridLayout()
        for i, (name, price, img_path) in enumerate(self.menu_items):
            # Create a button layout
            button_layout = QVBoxLayout()
            # Add image to the button
            pixmap = QPixmap(img_path)
            image_label = QLabel()
            image_label.setPixmap(pixmap)
            image_label.setScaledContents(True)
            image_label.setFixedSize(100, 100)  # Set fixed size to maintain aspect ratio
            button_layout.addWidget(image_label)
            # Add button to the layout
            button = QPushButton(f"{name} - ${price}")
            button.clicked.connect(lambda checked, n=name, p=price: self.addOrder(n, p))
            button_layout.addWidget(button)
            self.menu_buttons.addLayout(button_layout, i // 2, i % 2)
            self.order_counts[name] = 0

        layout.addLayout(self.menu_buttons)

        # Label to show current order
        self.order_label = QLabel("Current Order:")
        layout.addWidget(self.order_label)

        # Button to remove an order
        remove_button = QPushButton("Remove Order")
        remove_button.clicked.connect(self.removeOrder)
        layout.addWidget(remove_button)

        # Label to show total price
        self.total_price_label = QLabel("Total Price: $0.00")
        layout.addWidget(self.total_price_label)

        # Button to submit order to the kitchen
        submit_button = QPushButton("Submit Order")
        submit_button.clicked.connect(self.submitOrder)
        layout.addWidget(submit_button)

        # Label to display order status updates
        self.status_label = QLabel("Status: None")
        layout.addWidget(self.status_label)

        # Order Check section
        self.order_check_label = QLabel("Order Check:")
        layout.addWidget(self.order_check_label)

        self.order_check_list = QListWidget()
        layout.addWidget(self.order_check_list)

        # Button to make payment for selected order
        pay_button = QPushButton("Make Payment")
        pay_button.clicked.connect(self.makePayment)
        layout.addWidget(pay_button)

        self.setLayout(layout)
        self.setWindowTitle(f'Table {self.table_number} Order Display')
        self.show()

    def makePayment(self):
        current_item = self.order_check_list.currentItem()
        if current_item:
            order_text = current_item.text()
            self.order_check_list.takeItem(self.order_check_list.row(current_item))
            QMessageBox.information(self, "Payment", f"Payment successful for:\n{order_text}")

            # 결제 완료 정보를 KitchenOrderDisplay로 발행
            try:
                # 'Order: Table 1 Order: ...'에서 테이블 번호 추출
                table_number = int(order_text.split(' ')[2])  # 'Table 1'에서 번호 추출
                payment_msg = String()
                payment_msg.data = f"Payment completed for Table {table_number}"
                self.payment_publisher.publish(payment_msg)  # 올바른 payment_publisher 사용
                self.get_logger().info(f'Published payment completion for Table {table_number}')
            except ValueError:
                self.get_logger().error(f"Failed to extract table number from order text: {order_text}")
        else:
            QMessageBox.warning(self, "No Selection", "Please select an order to make payment.")


    def addOrder(self, item_name, item_price):
        # Increase order count for the selected item
        self.order_counts[item_name] += 1
        # Update total price
        self.total_price += item_price
        self.updateOrderLabel()

    def removeOrder(self):
        # Prompt the user to select an item to remove
        items = [item for item, count in self.order_counts.items() if count > 0]
        if not items:
            return

        item_name, ok = QInputDialog.getItem(self, "Remove Order", "Select item to remove:", items, 0, False)
        if ok and item_name:
            # Decrease order count for the selected item
            if self.order_counts[item_name] > 0:
                self.order_counts[item_name] -= 1
                # Update total price
                for name, price, _ in self.menu_items:
                    if name == item_name:
                        self.total_price -= price
                        break
                self.updateOrderLabel()

    def updateOrderLabel(self):
        # Update order display with the current order
        order_text = "Current Order:\n"
        for item, count in self.order_counts.items():
            if count > 0:
                order_text += f"{item}: {count}\n"
        self.order_label.setText(order_text)

        # Update total price label
        self.total_price_label.setText(f"Total Price: ${self.total_price:.2f}")

    def submitOrder(self):
        # Prepare an order message for submission
        order_message = f"Table {self.table_number} Order:\n"
        for item, count in self.order_counts.items():
            if count > 0:
                order_message += f"{item}: {count}\n"
        order_message += f"Total Price: ${self.total_price:.2f}\n"

        # Create and send a service request
        req = OrderService.Request()
        req.order_message = order_message
        future = self.client_.call_async(req)
        future.add_done_callback(lambda future: self.handle_service_response(future))

    def handle_service_response(self, future):
        try:
            response = future.result()
            if response.success:
                # Log the submitted order
                self.get_logger().info('Order submitted successfully')
                # Reset the current order after submission
                self.order_counts = {name: 0 for name in self.order_counts}
                self.total_price = 0.0
                self.updateOrderLabel()
            else:
                self.get_logger().error(f'Failed to submit the order: {response.response_message}')
        except Exception as e:
            self.get_logger().error(f'Service call failed: {e}')

    def receive_status_callback(self, msg):
        # 수신된 메시지를 통해 주문 정보와 상태 정보를 구분합니다.
        if "Status:" in msg.data:
            # 상태 정보 업데이트
            self.status_label.setText(f"Status: {msg.data.split(' - Status: ')[-1]}")
            self.get_logger().info(f'Received status update: {msg.data}')
        elif "Order:" in msg.data:
            # 주문 정보가 수신되면 Order Check에 추가
            self.order_check_list.addItem(msg.data)
            self.get_logger().info(f'Added to Order Check: {msg.data}')
        else:
            # 만약 수신된 메시지가 기존의 형식을 따르지 않는 경우 로깅
            self.get_logger().warning(f'Unexpected message format: {msg.data}')

def main(args=None):
    rclpy.init(args=args)
    app = QApplication(sys.argv)

    # 테이블 번호 선택 창
    table_number, ok = QInputDialog.getInt(None, "Select Table", "Enter table number (1-9):", min=1, max=9)
    if not ok:
        sys.exit()  # 사용자가 취소 버튼을 누르면 프로그램 종료

    # 선택한 테이블 번호에 대한 GUI만 생성
    node = TableOrderDisplay(table_number)

    # Multi-threaded executor to handle the ROS2 node
    executor = MultiThreadedExecutor()
    executor.add_node(node)

    # Run the executor in a separate thread
    ros_thread = threading.Thread(target=executor.spin, daemon=True)
    ros_thread.start()

    # Start the Qt GUI loop
    sys.exit(app.exec_())

    # Shutdown ROS after GUI exits
    rclpy.shutdown()

if __name__ == '__main__':
    main()
