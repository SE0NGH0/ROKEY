import rclpy
from rclpy.node import Node
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from time import sleep
import random
from std_msgs.msg import Bool


class tb1Navigator(Node):
    def __init__(self):
        super().__init__('tb1_navigator')

        # Initialize action client for tb1
        self.action_client = ActionClient(self, NavigateToPose, '/tb1/navigate_to_pose')

        # Define boundaries
        self.boundaries = [
            (-4.58, -2.16),
            (-2.63, -3.98),
            (1.85, -0.56),
            (0.65, 1.30),
            (3.39, 3.57),
            (1.87, 5.29),
            (0.33, 7.89),
            (-0.38, 5.92),
            (-1.25, 6.71),
            (-2.21, 7.97)
        ]

        # State variables
        self.stop_navigation = False
        self.waiting_for_start = False

        # Subscribers
        self.create_subscription(Bool, '/tb1/home_navigation', self.home_navigation_callback, 10)
        self.create_subscription(Bool, '/tb1/start_navigation', self.start_navigation_callback, 10)

    def home_navigation_callback(self, msg):
        """Callback for the home_navigation topic."""
        if msg.data:
            self.stop_navigation = True  # Halt current navigation
            self.waiting_for_start = True  # Enter waiting mode
            self.get_logger().info("[INFO] Home signal received. Halting navigation and entering wait mode.")

    def start_navigation_callback(self, msg):
        """Callback for the start_navigation topic."""
        if msg.data:
            self.stop_navigation = False  # Resume navigation
            self.waiting_for_start = False  # Exit waiting mode
            self.get_logger().info("[INFO] Start signal received. Resuming navigation.")

    def send_goal(self, goal):
        """Send a navigation goal to the action server."""
        if self.stop_navigation:
            self.get_logger().info("[INFO] Navigation halted. Not sending goal.")
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = goal['x']
        goal_msg.pose.pose.position.y = goal['y']
        goal_msg.pose.pose.orientation.z = self.yaw_to_quaternion(goal['yaw'])['z']
        goal_msg.pose.pose.orientation.w = self.yaw_to_quaternion(goal['yaw'])['w']

        self.get_logger().info(f"Sending goal to tb1: {goal}")

        self.action_client.wait_for_server()
        send_goal_future = self.action_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, send_goal_future)
        goal_handle = send_goal_future.result()

        if not goal_handle.accepted:
            self.get_logger().error(f"Goal rejected: {goal}")
            return None

        self.get_logger().info("Goal accepted, waiting for result...")

        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        result = result_future.result()

        if result.status != 4:  # 4 indicates SUCCESS
            self.get_logger().error(f"Navigation failed with status: {result.status}")
        else:
            self.get_logger().info("Navigation successful!")

    def yaw_to_quaternion(self, yaw):
        """Convert yaw to quaternion."""
        import math
        return {
            'z': math.sin(yaw / 2.0),
            'w': math.cos(yaw / 2.0)
        }

    def run(self):
        """Main loop for the navigator."""
        while rclpy.ok():
            # Process ROS events
            rclpy.spin_once(self, timeout_sec=0.1)

            if self.waiting_for_start:
                # Wait for a start signal
                self.get_logger().info("[INFO] Waiting for start signal...")
                sleep(1)  # Prevent tight looping during wait
                continue

            for _ in range(10):  # Number of random goals to send
                if self.stop_navigation:
                    self.get_logger().info("[INFO] Navigation halted mid-loop.")
                    break

                goal_point = random.choice(self.boundaries)
                goal = {'x': goal_point[0], 'y': goal_point[1], 'yaw': 0.0}
                self.send_goal(goal)
                self.get_logger().info(f'tb1 is navigating to: {goal}')

                # Process events while navigating
                for _ in range(50):  # Roughly 5 seconds of checks
                    if self.stop_navigation:
                        self.get_logger().info("[INFO] Navigation halted mid-goal.")
                        break
                    rclpy.spin_once(self, timeout_sec=0.1)
                    sleep(0.1)

        self.get_logger().info('[INFO] tb1 navigation complete.')


def main():
    rclpy.init()
    navigator = tb1Navigator()
    try:
        navigator.run()
    finally:
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
