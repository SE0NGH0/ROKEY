import sys
import threading
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import OccupancyGrid
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTextEdit, QMessageBox, QPushButton, QHBoxLayout
from PyQt5.QtCore import QTimer, Qt, pyqtSignal, QObject
from PyQt5.QtGui import QPixmap, QImage, QPainter, QColor, QFont
import numpy as np
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Bool
from cv_bridge import CvBridge
from sensor_msgs.msg import Image

class Communicate(QObject):
    update_signal = pyqtSignal()

class MultiRobotGUI(Node, QWidget):
    def __init__(self):
        Node.__init__(self, 'multi_robot_gui')
        QWidget.__init__(self)
        self.comm = Communicate()
        self.comm.update_signal.connect(self.update_gui)

        self.initUI()

        # Initialize variables to store robot positions
        self.tb1_pose = None
        self.tb2_pose = None

        # Initialize map data
        self.map_data = None
        self.bridge = CvBridge()  # CV Bridge for image conversion
        self.tb1_camera_image = None  # Store the latest TB1 camera image
        self.tb2_camera_image = None  # Store the latest TB2 camera image

        self.tb1_home = {'x': -8.22167, 'y': 10.2748 ,'theta': 0.0}
        self.tb2_home = {'x': 0.0229327, 'y': -0.769658, 'theta': 0.0}
        
        # ROS2 Subscribers
        self.tb1_pose_subscriber = self.create_subscription(
            PoseWithCovarianceStamped, '/tb1/amcl_pose', self.tb1_pose_callback, 10)
        self.tb2_pose_subscriber = self.create_subscription(
            PoseWithCovarianceStamped, '/tb2/amcl_pose', self.tb2_pose_callback, 10)
        self.map_subscriber = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, 10)
        self.tb1_camera_subscriber = self.create_subscription(
            Image, '/tb1/camera/image_raw', self.tb1_camera_callback, 10)
        self.tb2_camera_subscriber = self.create_subscription(
            Image, '/tb2/camera/image_raw', self.tb2_camera_callback, 10)
        self.tb1_navigation_client = ActionClient(self, NavigateToPose, '/tb1/navigate_to_pose')
        self.tb2_navigation_client = ActionClient(self, NavigateToPose, '/tb2/navigate_to_pose')

        # Timer for updating GUI (optional, since we use signals)
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_gui)
        self.update_timer.start(100)  # Update every 500 ms

    def initUI(self):
        self.setWindowTitle("Multi-Robot GUI with Dynamic Map")
        layout = QVBoxLayout()

        # Add labels for robot positions
        self.tb1_label = QLabel("TB1 Position: Not Available")
        self.tb2_label = QLabel("TB2 Position: Not Available")
        layout.addWidget(self.tb1_label)
        layout.addWidget(self.tb2_label)

        # Map display label
        self.map_label = QLabel("Map not available")
        self.map_label.setAlignment(Qt.AlignCenter)
        self.map_label.setFixedSize(413, 406)  # Set desired map display size
        layout.addWidget(self.map_label)

        # Camera display labels
        camera_layout = QHBoxLayout()
        self.tb1_camera_label = QLabel("TB1 Camera feed not available")
        self.tb1_camera_label.setAlignment(Qt.AlignCenter)
        self.tb1_camera_label.setFixedSize(320, 240)  # Set TB1 camera display size
        camera_layout.addWidget(self.tb1_camera_label)

        self.tb2_camera_label = QLabel("TB2 Camera feed not available")
        self.tb2_camera_label.setAlignment(Qt.AlignCenter)
        self.tb2_camera_label.setFixedSize(320, 240)  # Set TB2 camera display size
        camera_layout.addWidget(self.tb2_camera_label)
        layout.addLayout(camera_layout)

        # Add buttons for home position
        self.tb1_home_button = QPushButton("Move TB1 to Home")
        self.tb1_home_button.clicked.connect(self.move_tb1_to_home)
        layout.addWidget(self.tb1_home_button)

        self.tb2_home_button = QPushButton("Move TB2 to Home")
        self.tb2_home_button.clicked.connect(self.move_tb2_to_home)
        layout.addWidget(self.tb2_home_button)

        # Add buttons for home position
        self.tb1_start_button = QPushButton("Starting TB1")
        self.tb1_start_button.clicked.connect(self.start_tb1)
        layout.addWidget(self.tb1_start_button)

        self.tb2_start_button = QPushButton("Starting TB2")
        self.tb2_start_button.clicked.connect(self.start_tb2)
        layout.addWidget(self.tb2_start_button)

        # Add text display for detailed logs
        self.log_display = QTextEdit()
        self.log_display.setReadOnly(True)
        layout.addWidget(self.log_display)

        self.setLayout(layout)
        self.show()

    def log_message(self, message):
        self.log_display.append(message)

    def tb1_camera_callback(self, msg):
        """Callback for receiving TB1 camera images."""
        try:
            self.tb1_camera_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception as e:
            self.log_message(f"[ERROR] Failed to process TB1 camera image: {e}")

    def tb2_camera_callback(self, msg):
        """Callback for receiving TB2 camera images."""
        try:
            self.tb2_camera_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception as e:
            self.log_message(f"[ERROR] Failed to process TB2 camera image: {e}")

    def map_callback(self, msg):
        self.map_data = msg
        self.log_message("[INFO] Received new map data")
        self.comm.update_signal.emit()

    def tb1_pose_callback(self, msg):
        self.tb1_pose = msg.pose.pose
        self.log_message("[INFO] Received TB1 pose")
        self.comm.update_signal.emit()

    def tb2_pose_callback(self, msg):
        self.tb2_pose = msg.pose.pose
        self.log_message("[INFO] Received TB2 pose")
        self.comm.update_signal.emit()

    def move_tb1_to_home(self):
        self.log_message("[INFO] Moving TB1 to Home Position")
        self.send_navigation_goal(self.tb1_navigation_client, self.tb1_home)

        # 퍼블리셔로 stop_navigation 신호 전송
        home_publisher = self.create_publisher(Bool, '/tb1/home_navigation', 10)
        home_msg = Bool()
        home_msg.data = True
        home_publisher.publish(home_msg)

    def move_tb2_to_home(self):
        self.log_message("[INFO] Moving TB2 to Home Position")
        self.send_navigation_goal(self.tb2_navigation_client, self.tb2_home)

        # 퍼블리셔로 stop_navigation 신호 전송
        home_publisher = self.create_publisher(Bool, '/tb2/home_navigation', 10)
        home_msg = Bool()
        home_msg.data = True
        home_publisher.publish(home_msg)

    def start_tb1(self):
        self.log_message("[INFO] Starting TB1")

        # 퍼블리셔로 stop_navigation 신호 전송
        start_publisher = self.create_publisher(Bool, '/tb1/start_navigation', 10)
        start_msg = Bool()
        start_msg.data = True
        start_publisher.publish(start_msg)

    def start_tb2(self):
        self.log_message("[INFO] Starting TB2")

        # 퍼블리셔로 stop_navigation 신호 전송
        start_publisher = self.create_publisher(Bool, '/tb2/start_navigation', 10)
        start_msg = Bool()
        start_msg.data = True
        start_publisher.publish(start_msg)
        

    def send_navigation_goal(self, client, home_position):
        if not client.wait_for_server(timeout_sec=5.0):
            self.log_message("[ERROR] Navigation server not available!")
            return

        goal_msg = NavigateToPose.Goal()
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = home_position['x']
        pose.pose.position.y = home_position['y']
        pose.pose.orientation.z = np.sin(home_position['theta'] / 2.0)
        pose.pose.orientation.w = np.cos(home_position['theta'] / 2.0)
        goal_msg.pose = pose

        self.log_message(f"[INFO] Sending navigation goal: {home_position}")
        future = client.send_goal_async(goal_msg)
        future.add_done_callback(self.navigation_goal_response_callback)

    def navigation_goal_response_callback(self, future):
        result = future.result()
        if not result.accepted:
            self.log_message("[ERROR] Navigation goal rejected")
            return

        self.log_message("[INFO] Navigation goal accepted")
        result_future = result.get_result_async()
        result_future.add_done_callback(self.navigation_result_callback)

    def navigation_result_callback(self, future):
        try:
            result = future.result()
            if result.status == 4:  # 4: SUCCESS (표준 ROS2 Navigation 상태 코드)
                self.log_message("[INFO] Successfully reached home position")
            else:
                self.log_message(f"[ERROR] Navigation failed with status code: {result.status}")
        except Exception as e:
            self.log_message(f"[ERROR] Navigation result callback failed: {e}")

    def update_gui(self):
        # Update robot position labels
        if self.tb1_pose:
            self.tb1_label.setText(f"TB1 Position: x={self.tb1_pose.position.x:.2f}, y={self.tb1_pose.position.y:.2f}")
        else:
            self.tb1_label.setText("TB1 Position: Not Available")

        if self.tb2_pose:
            self.tb2_label.setText(f"TB2 Position: x={self.tb2_pose.position.x:.2f}, y={self.tb2_pose.position.y:.2f}")
        else:
            self.tb2_label.setText("TB2 Position: Not Available")

        # Update map display
        self.display_map()

        # Update camera feeds
        self.display_camera_feed(self.tb1_camera_image, self.tb1_camera_label, "TB1")
        self.display_camera_feed(self.tb2_camera_image, self.tb2_camera_label, "TB2")

    def display_camera_feed(self, image, label, robot_name):
        if image is None:
            label.setText(f"{robot_name} Camera feed not available")
            return

        try:
            # Convert OpenCV image to QImage
            height, width, channel = image.shape
            bytes_per_line = channel * width
            qimage = QImage(image.data, width, height, bytes_per_line, QImage.Format_BGR888)
            pixmap = QPixmap.fromImage(qimage).scaled(
                label.width(), label.height(), Qt.KeepAspectRatio
            )
            label.setPixmap(pixmap)
        except Exception as e:
            self.log_message(f"[ERROR] Failed to display {robot_name} camera feed: {e}")

    # Other existing methods (move_tb1_to_home, start_tb1, etc.) remain unchanged.
    
    def display_map(self):
        if self.map_data is None:
            self.map_label.setText("Map not available")
            return

        try:
            # Convert OccupancyGrid to image
            width = self.map_data.info.width
            height = self.map_data.info.height
            map_array = np.array(self.map_data.data).reshape((height, width))
            map_array = np.flip(map_array, axis=0)  # Flip vertically to correct orientation

            # Convert occupancy values to RGB
            map_image = np.zeros((height, width, 3), dtype=np.uint8)
            map_image[map_array == 0] = [255, 255, 255]      # Free space - White
            map_image[map_array == 100] = [0, 0, 0]          # Occupied space - Black
            map_image[map_array == -1] = [128, 128, 128]     # Unknown space - Gray

            # Convert numpy array to QImage
            qimage = QImage(map_image.data, width, height, width * 3, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qimage).scaled(
                self.map_label.width(), self.map_label.height(), Qt.KeepAspectRatio)

            # Create a new QPixmap with rotation
            rotated_pixmap = QPixmap(self.map_label.width(), self.map_label.height())
            rotated_pixmap.fill(Qt.transparent)  # Transparent background

            painter = QPainter(rotated_pixmap)
            painter.setRenderHint(QPainter.Antialiasing)

            # Apply rotation (rotate 90 degrees clockwise)
            painter.translate(rotated_pixmap.width() / 2, rotated_pixmap.height() / 2)
            painter.rotate(-90)  # Rotate counter-clockwise (RViz 기준)

            # Draw the original pixmap onto the rotated canvas
            painter.translate(-pixmap.width() / 2, -pixmap.height() / 2)
            painter.drawPixmap(0, 0, pixmap)

            # Draw robot positions
            if self.tb1_pose:
                x_pixel, y_pixel = self.world_to_pixel(
                    self.tb1_pose.position.x, self.tb1_pose.position.y)
                painter.setBrush(QColor(255, 0, 0))  # Red color for TB1
                painter.setPen(QColor(255, 0, 0))
                painter.drawEllipse(x_pixel - 5, y_pixel - 5, 10, 10)
                painter.setFont(QFont("Arial", 12))
                painter.drawText(x_pixel + 5, y_pixel - 5, "TB1")

            if self.tb2_pose:
                x_pixel, y_pixel = self.world_to_pixel(
                    self.tb2_pose.position.x, self.tb2_pose.position.y) 
                # x_pixel += 80  # 위로 10 픽셀 이동
                # y_pixel += 120
                painter.setBrush(QColor(0, 0, 255))  # Blue color for TB2
                painter.setPen(QColor(0, 0, 255))
                painter.drawEllipse(x_pixel - 5, y_pixel - 5, 10, 10)
                painter.setFont(QFont("Arial", 12))
                painter.drawText(x_pixel + 5, y_pixel - 5, "TB2")

            painter.end()

            # Set the rotated pixmap to the map_label
            self.map_label.setPixmap(rotated_pixmap)

        except Exception as e:
            self.log_message(f"[ERROR] Failed to display map: {e}")
            QMessageBox.critical(self, "Error", f"Failed to display map: {e}")


    def world_to_pixel(self, x, y):
        """
        Convert world coordinates to pixel coordinates based on map metadata,
        and apply an offset to adjust the robot position display.
        """
        try:
            resolution = self.map_data.info.resolution  # 맵 해상도
            origin_x = self.map_data.info.origin.position.x  # 맵 원점 x
            origin_y = self.map_data.info.origin.position.y  # 맵 원점 y
            width = self.map_data.info.width  # 맵의 너비 (픽셀)
            height = self.map_data.info.height  # 맵의 높이 (픽셀)

            # 월드 좌표를 픽셀 좌표로 변환
            x_pixel = int((x - origin_x) / resolution)
            y_pixel = int((y - origin_y) / resolution)

            # 오프셋을 적용 (오른쪽 대각선 위로 이동)
            # x_offset = 50  # 오른쪽으로 10 픽셀 이동
            # y_offset = -50  # 위로 10 픽셀 이동
            # x_pixel += x_offset
            # y_pixel += y_offset

            # QImage 좌표계에 맞추기
            y_pixel = height - y_pixel - 1  # -1 추가로 경계 문제 방지

            return x_pixel, y_pixel
        except Exception as e:
            self.log_message(f"[ERROR] World to pixel conversion failed: {e}")
            return 0, 0

def main(args=None):
    rclpy.init(args=args)
    app = QApplication(sys.argv)
    gui = MultiRobotGUI()

    # Run ROS2 spin in a separate thread to avoid blocking the GUI
    ros_thread = threading.Thread(target=rclpy.spin, args=(gui,), daemon=True)
    ros_thread.start()

    try:
        sys.exit(app.exec_())
    except KeyboardInterrupt:
        pass
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()

