import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from time import sleep
import numpy as np

class MultiRobotNavigator(Node):
    def __init__(self):
        super().__init__('multi_robot_navigator')

        # Define namespaces for each robot
        self.robot_namespaces = ['tb1', 'tb2']
        self.action_clients = {}

        # Initialize action clients for each robot
        for namespace in self.robot_namespaces:
            self.action_clients[namespace] = ActionClient(
                self, NavigateToPose, f'/{namespace}/navigate_to_pose')

        # Define map boundaries from the provided data
        self.boundaries = [
            (4.019608974456787, 3.5347278118133545),
            (1.2825863361358643, 1.2310653924942017),
            (2.5168240070343018, -0.6527102589607239),
            (-2.72446870803833, -4.802400588989258),
            (-4.585601329803467, -2.6782002449035645),
            (-6.993764877319336, -4.273244857788086),
            (-13.468293190002441, 4.053033828735352),
            (-11.469295501708984, 6.006489276885986),
            (-12.93739128112793, 8.368538856506348),
            (-7.746028423309326, 12.350281715393066),
            (-6.1611714363098145, 10.706232070922852),
            (-3.0480127334594727, 12.865640640258789),
        ]

        # Calculate x_center to divide the map
        x_coords = [point[0] for point in self.boundaries]
        x_center = (min(x_coords) + max(x_coords)) / 2

        # Assign goals to each robot based on their respective zones
        self.goals = {
            'tb1': self.generate_zigzag_goals(self.boundaries, 1.0, x_center, 'right'),
            'tb2': self.generate_zigzag_goals(self.boundaries, 1.0, x_center, 'left')
        }

    def generate_zigzag_goals(self, boundaries, grid_spacing, x_center, side):
        """
        Generate zigzag goals for the left or right side of the map.
        :param boundaries: List of map boundary coordinates
        :param grid_spacing: Spacing between grid points (in meters)
        :param x_center: x-coordinate dividing the map into left and right
        :param side: 'left' or 'right' to determine the zone
        :return: List of waypoints for the specified side
        """
        x_coords = [point[0] for point in boundaries]
        y_coords = [point[1] for point in boundaries]
        min_x, max_x = min(x_coords), max(x_coords)
        min_y, max_y = min(y_coords), max(y_coords)

        # Adjust x range based on the side
        if side == 'left':
            max_x = x_center
        elif side == 'right':
            min_x = x_center

        # Generate grid points
        x_points = np.arange(min_x, max_x, grid_spacing)
        y_points = np.arange(min_y, max_y, grid_spacing)

        # Generate zigzag path
        waypoints = []
        for i, y in enumerate(y_points):
            if i % 2 == 0:
                # Left-to-right for even rows
                for x in x_points:
                    waypoints.append({'x': x, 'y': y, 'yaw': 0.0})
            else:
                # Right-to-left for odd rows
                for x in reversed(x_points):
                    waypoints.append({'x': x, 'y': y, 'yaw': 0.0})
        return waypoints

    def send_goal(self, namespace, goal):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = goal['x']
        goal_msg.pose.pose.position.y = goal['y']
        goal_msg.pose.pose.orientation.z = self.yaw_to_quaternion(goal['yaw'])['z']
        goal_msg.pose.pose.orientation.w = self.yaw_to_quaternion(goal['yaw'])['w']

        self.get_logger().info(f'Sending goal to {namespace}: {goal}')
        
        self.action_clients[namespace].wait_for_server()
        send_goal_future = self.action_clients[namespace].send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, send_goal_future)
        goal_handle = send_goal_future.result()

        if not goal_handle.accepted:
            self.get_logger().error(f'Goal rejected by {namespace}')
            return None

        self.get_logger().info(f'Goal accepted by {namespace}')
        return goal_handle

    def yaw_to_quaternion(self, yaw):
        import math
        return {
            'z': math.sin(yaw / 2.0),
            'w': math.cos(yaw / 2.0)
        }

    def run(self):
        for namespace in self.robot_namespaces:
            for goal in self.goals[namespace]:
                self.send_goal(namespace, goal)
                self.get_logger().info(f'{namespace} is navigating to: {goal}')
                sleep(5)  # Add delay between goals

        self.get_logger().info('All goals sent. Navigation started.')

def main():
    rclpy.init()
    navigator = MultiRobotNavigator()
    navigator.run()
    rclpy.spin(navigator)
    navigator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
