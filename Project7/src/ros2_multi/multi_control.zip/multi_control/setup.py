from setuptools import find_packages, setup

package_name = 'multi_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(),  # 모든 Python 패키지를 자동으로 탐색
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='moon0',
    maintainer_email='moon0@todo.todo',
    description='Multi-control package for TurtleBot3',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'multi_con = multi_control.multi_control:main',
            'nav = multi_control.nav2:main',
            'tb1 = multi_control.tb1:main',
            'tb2 = multi_control.tb2:main',
            'gui = multi_control.gui:main',
        ],
    },
)
