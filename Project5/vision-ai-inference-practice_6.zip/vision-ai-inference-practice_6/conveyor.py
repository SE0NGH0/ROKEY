import time
import serial
import requests
import numpy as np
import os
import cv2
import json
import logging
import random
import sqlite3  # SQLite3 임포트
from datetime import datetime  # 타임스탬프 처리를 위한 datetime 임포트
from requests.auth import HTTPBasicAuth

# -------------------------------
# 1. Logging Configuration
# -------------------------------
logging.basicConfig(
    level=logging.INFO,  # 자세한 로그를 원하면 DEBUG으로 변경
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("app.log", encoding='utf-8'),  # 로그 파일 (UTF-8 인코딩)
        logging.StreamHandler()                              # 콘솔 출력
    ]
)

# -------------------------------
# 2. API Configuration
# -------------------------------
URL = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/f928ebdf-89bd-4611-9c8a-dc9fe2da0049/inference"
ACCESS_KEY = "NbeRrNlMV99thyzJbJJ4k5NqIKm61TQU9iXRfYRx"
USERNAME = "kdt2024_1-26"

# -------------------------------
# 3. Serial Port Initialization
# -------------------------------
SERIAL_PORT = "/dev/ttyACM0"  # 필요에 따라 변경
BAUD_RATE = 9600

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)  # 타임아웃 1초
    logging.info(f"Connected to serial port {SERIAL_PORT}.")
except serial.SerialException as e:
    logging.error(f"Failed to connect to serial port: {e}")
    exit(1)

# -------------------------------
# 4. Directory Configuration
# -------------------------------
SAVE_DIR = "/home/rokey/vision-ai-inference-practice/save_dir"  # 원본 이미지 저장 디렉토리
ANNOTATED_DIR = "/home/rokey/vision-ai-inference-practice/annotate_dir"  # 주석 이미지 저장 디렉토리
NORMAL_DIR = "/home/rokey/vision-ai-inference-practice/annotate_dir/normal"  # 정상 제품 주석 이미지 디렉토리
DEFECTIVE_DIR = "/home/rokey/vision-ai-inference-practice/annotate_dir/defective"  # 불량 제품 주석 이미지 디렉토리

# 디렉토리 생성
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(ANNOTATED_DIR, exist_ok=True)
os.makedirs(NORMAL_DIR, exist_ok=True)
os.makedirs(DEFECTIVE_DIR, exist_ok=True)

# -------------------------------
# 5. Normal Product Judgment Criteria
# -------------------------------
NORMAL_CRITERIA = {
    #"RASPBERRY PICO": 1,
    "BOOTSEL": 1,
    "CHIPSET": 1,
    "OSCILLATOR": 1,
    "USB": 1,
    "HOLE": 4
}

# -------------------------------
# 6. Database Initialization
# -------------------------------
def init_db(db_path="products.db"):
    """데이터베이스 초기화 및 테이블 생성"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    # 정상품 테이블 생성
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS normal_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            image_path TEXT NOT NULL
        )
    """)
    # 불량품 테이블 생성
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS defective_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            image_path TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn

# -------------------------------
# 7. Function Definitions
# -------------------------------

def get_img(cam):
    """USB 카메라로부터 이미지를 캡처하여 반환합니다."""
    ret, img = cam.read()
    if not ret:
        logging.error("Failed to capture image from camera.")
        return None
    return img

def crop_img(img):
    """이미지를 지정된 영역으로 크롭하고 밝기를 조정합니다."""
    size_dict = {"x": 800, "y": 380, "width": 400, "height": 550}
    x = size_dict["x"]
    y = size_dict["y"]
    w = size_dict["width"]
    h = size_dict["height"]
    img_cropped = img[y : y + h, x : x + w]
    # 밝기 조정
    img_bright = cv2.convertScaleAbs(img_cropped, alpha=1, beta=5)
    return img_bright

def save_img(img, save_dir, index):
    """이미지를 지정된 디렉토리에 저장합니다."""
    image_path = os.path.join(save_dir, f"new{index}.jpg")
    cv2.imwrite(image_path, img)
    logging.info(f"Image saved: {image_path}")
    return index + 1

def inference_request(img: np.array, api_url: str):
    """이미지를 API로 전송하여 추론을 요청합니다.
    Args:
        img (numpy.array): 추론할 이미지
        api_url (str): API 엔드포인트 URL
    Returns:
        dict: API 응답 JSON 또는 None
    """
    try:
        # JPEG 인코딩
        _, img_encoded = cv2.imencode(".jpg", img)
        image_data = img_encoded.tobytes()

        # API 요청
        start_time = time.time()
        response = requests.post(
            url=api_url,
            auth=HTTPBasicAuth(USERNAME, ACCESS_KEY),
            headers={"Content-Type": "image/jpeg"},
            data=image_data
        )
        api_time = time.time() - start_time
        logging.info(f"API request time: {api_time:.2f} seconds")

        # 응답 상태 코드 로그
        logging.info(f"API response status code: {response.status_code}")

        if response.status_code == 200:
            response_json = response.json()
            logging.info(f"API response: {json.dumps(response_json, indent=4, ensure_ascii=False)}")
            return response_json
        else:
            logging.error(f"Image upload failed. Status code: {response.status_code}")
            logging.error(f"Response content: {response.text}")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"Error during request transmission: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected error occurred: {e}")
        return None

def annotate_image(image, response_json, colors, normal_criteria):
    """API 응답을 기반으로 이미지를 주석 처리합니다.
    Args:
        image (numpy.array): 원본 이미지
        response_json (dict): API 응답 JSON
        colors (dict): 클래스별 색상 매핑
        normal_criteria (dict): 정상 판정 기준
    Returns:
        tuple: 주석이 추가된 이미지, 정상 여부 (True/False)
    """
    if not response_json:
        logging.warning("No API response for annotation.")
        return image, False

    objects = response_json.get('objects', [])
    if not objects:
        logging.info("No objects detected.")
        return image, False

    class_counts = {}
    # Bounding Box 및 레이블 그리기
    for obj in objects:
        class_name = obj['class'].strip().upper()
        score = obj.get('score', 0.0)
        box = obj.get('box', [0, 0, 0, 0])
        if len(box) != 4:
            logging.warning(f"Invalid box coordinates: {box}")
            continue
        x1, y1, x2, y2 = box

        # 클래스별 개수 카운트
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

        # Bounding Box 그리기
        color = colors.get(class_name, (0, 255, 0))  # 기본 색상: 녹색
        thickness = 2
        cv2.rectangle(image, (x1, y1), (x2, y2), color, thickness)

        # 레이블 그리기
        label = f"{class_name}: {score:.2f}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.5
        font_thickness = 1
        text_size, _ = cv2.getTextSize(label, font, font_scale, font_thickness)
        text_w, text_h = text_size
        # 텍스트 배경 사각형
        cv2.rectangle(image, (x1, y1 - text_h - 4), (x1 + text_w, y1), color, -1)
        # 텍스트 그리기
        cv2.putText(image, label, (x1, y1 - 2), font, font_scale, (255, 255, 255), font_thickness, cv2.LINE_AA)

    # 클래스별 개수를 내림차순으로 정렬
    sorted_class_info = sorted(class_counts.items(), key=lambda item: item[1], reverse=True)
    class_info_lines = [f"{cls}: {count}" for cls, count in sorted_class_info]

    # 클래스 정보 텍스트 그리기
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    font_thickness = 2
    line_height = 20
    padding = 10

    # 텍스트 배경 사각형 크기 계산
    max_text_w = 0
    for line in class_info_lines:
        text_size, _ = cv2.getTextSize(line, font, font_scale, font_thickness)
        text_w, _ = text_size
        if text_w > max_text_w:
            max_text_w = text_w
    total_text_h = line_height * len(class_info_lines)

    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (padding - 5, padding - 5),
        (padding + max_text_w + 10, padding + total_text_h + 5),
        (0, 0, 0),  # 검은색
        -1
    )

    # 각 클래스별 정보 텍스트 그리기
    for idx, line in enumerate(class_info_lines):
        text_position = (padding, padding + (idx + 1) * line_height)
        cv2.putText(
            image,
            line,
            text_position,
            font,
            font_scale,
            (255, 255, 255),  # 흰색
            font_thickness,
            cv2.LINE_AA
        )

    # 정상 제품 판정
    is_normal = True
    for key, value in normal_criteria.items():
        detected = class_counts.get(key.upper(), 0)
        if detected != value:
            logging.warning(f"Mismatch detected - {key.upper()}: Expected {value}, Found {detected}")
            is_normal = False
            break
    # 정상 기준에 없는 클래스가 감지되었는지도 확인
    """
    if is_normal:
        for detected_class in class_counts.keys():
            if detected_class not in normal_criteria:
                logging.warning(f"Unexpected class detected: {detected_class}")
                is_normal = False
                break
    """

    # 판정 결과 텍스트 및 색상 설정
    if is_normal:
        status_text = "Normal"
        status_color = (0, 255, 0)  # 녹색
    else:
        status_text = "Poor"
        status_color = (0, 0, 255)  # 빨간색

    # 판정 결과 텍스트 그리기
    status_font_scale = 1.0
    status_font_thickness = 2
    status_text_size, _ = cv2.getTextSize(status_text, font, status_font_scale, status_font_thickness)
    status_text_w, status_text_h = status_text_size

    # 이미지의 오른쪽 하단 좌표 계산
    image_height, image_width = image.shape[:2]
    status_padding = 10
    status_x = image_width - status_text_w - status_padding
    status_y = image_height - status_padding

    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (status_x - 5, status_y - status_text_h - 5),
        (status_x + status_text_w + 5, status_y + 5),
        status_color,
        -1
    )

    # 판정 결과 텍스트 그리기 (흰색 글씨)
    cv2.putText(
        image,
        status_text,
        (status_x, status_y),
        font,
        status_font_scale,
        (255, 255, 255),  # 흰색
        status_font_thickness,
        cv2.LINE_AA
    )

    return image, is_normal  # 3. 정상 여부 반환

# -------------------------------
# 8. Main Function Definition
# -------------------------------
def main():
    # 데이터베이스 초기화
    conn = init_db()
    cursor = conn.cursor()

    # 카메라 초기화
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        logging.error("Cannot open camera.")
        exit(-1)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    logging.info("Camera initialized successfully.")

    # 색상 매핑 딕셔너리 초기화
    colors = {}

    # 이미지 인덱스 초기화
    image_index = 0

    try:
        while True:
            # 시리얼 포트로부터 데이터 읽기
            data = ser.read(1)  # 1바이트 읽기
            if data == b"0":
                logging.info("Trigger signal received: Starting image capture.")

                # 트리거 신호 후 지연 시간 추가 (객체 안정화)
                time.sleep(1.5)  # 1.5초 대기

                # 이미지 캡처
                start_capture = time.time()
                img = get_img(cam)
                capture_time = time.time() - start_capture
                logging.info(f"Image capture time: {capture_time:.2f} seconds")

                if img is None:
                    continue
                img_cropped = crop_img(img)

                # 이미지 저장
                start_save = time.time()
                image_index = save_img(img_cropped, SAVE_DIR, image_index)
                save_time = time.time() - start_save
                logging.info(f"Image save time: {save_time:.2f} seconds")

                # API에 이미지 전송
                start_api = time.time()
                response = inference_request(img_cropped, URL)
                api_call_time = time.time() - start_api
                logging.info(f"API call time: {api_call_time:.2f} seconds")

                if response and 'objects' in response:
                    # 클래스별 색상 매핑 업데이트
                    for obj in response['objects']:
                        class_name = obj['class'].strip().upper()
                        if class_name not in colors:
                            colors[class_name] = tuple(random.randint(0, 255) for _ in range(3))
                else:
                    logging.warning(f"No 'objects' in API response. Image {image_index} considered defective.")

                # 이미지 주석 처리
                start_annotate = time.time()
                annotated_img, is_normal = annotate_image(img_cropped.copy(), response, colors, NORMAL_CRITERIA)
                annotate_time = time.time() - start_annotate
                logging.info(f"Image annotation time: {annotate_time:.2f} seconds")

                # 주석이 추가된 이미지 저장 경로 결정
                if is_normal:
                    annotated_image_path = os.path.join(NORMAL_DIR, f"annotated_normal_{image_index}.jpg")
                else:
                    annotated_image_path = os.path.join(DEFECTIVE_DIR, f"annotated_defective_{image_index}.jpg")

                # 주석이 추가된 이미지 저장
                start_save_annotated = time.time()
                cv2.imwrite(annotated_image_path, annotated_img)
                save_annotated_time = time.time() - start_save_annotated
                logging.info(f"Annotated image saved: {annotated_image_path} (Time: {save_annotated_time:.2f} seconds)")

                # 데이터베이스에 기록 추가
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                start_db = time.time()
                if is_normal:
                    cursor.execute("""
                        INSERT INTO normal_products (timestamp, image_path)
                        VALUES (?, ?)
                    """, (timestamp, annotated_image_path))
                    logging.info(f"Recorded as Normal product at {timestamp}.")
                else:
                    cursor.execute("""
                        INSERT INTO defective_products (timestamp, image_path)
                        VALUES (?, ?)
                    """, (timestamp, annotated_image_path))
                    logging.info(f"Recorded as Defective product at {timestamp}.")
                conn.commit()
                db_time = time.time() - start_db
                logging.info(f"Database insert time: {db_time:.2f} seconds")

                # 시리얼 포트로 응답 전송
                start_serial = time.time()
                ser.write(b"1")
                serial_time = time.time() - start_serial
                logging.info(f"Sent response '1' for image {image_index} (Time: {serial_time:.2f} seconds).")

                # 이미지 디스플레이 (옵션)
                start_display = time.time()
                cv2.imshow("Annotated Image", annotated_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    logging.info("Quit signal received: Preparing to exit program.")
                    break
                display_time = time.time() - start_display
                logging.info(f"Image display time: {display_time:.2f} seconds")
            else:
                # 다른 데이터는 무시하거나 필요에 따라 처리
                pass
    except KeyboardInterrupt:
        logging.info("KeyboardInterrupt received: Preparing to exit program.")
    except Exception as e:
        logging.error(f"Error in main loop: {e}")
    finally:
        # 데이터베이스 연결 종료
        conn.close()
        logging.info("Database connection closed.")

        # 자원 해제
        cam.release()
        ser.close()
        cv2.destroyAllWindows()
        logging.info("Program terminated successfully.")

if __name__ == "__main__":
    main()
