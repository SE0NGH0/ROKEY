import time
import serial
import requests
import numpy as np
from io import BytesIO
from pprint import pprint
import os
import cv2
import json
import logging
# 로깅 설정
logging.basicConfig(
    level=logging.INFO,  # 디버깅을 위해 DEBUG로 변경할 수 있습니다.
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
# API 설정 (환경 변수 사용 권장)
api_url = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/0d7c75a6-0bf4-4948-a2c9-00021428fd64/inference"
# 시리얼 포트 설정 (환경 변수 사용 권장)
serial_port = "/dev/ttyACM0"
ser = serial.Serial(serial_port, 9600, timeout=1)  # 타임아웃 설정
# 이미지 디렉토리 설정
IMAGE_DIR = "/home/rokey/vision-ai-inference-practice/img_dir"
SAVE_DIR = "/home/rokey/vision-ai-inference-practice/save_dir"  # 원본 이미지 저장 디렉토리
ANNOTATED_DIR = "/home/rokey/vision-ai-inference-practice/annotate_dir"  # 주석 이미지 저장 디렉토리
# 출력 디렉토리가 존재하지 않으면 생성
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(ANNOTATED_DIR, exist_ok=True)
# 처리할 이미지 확장자 리스트
IMAGE_EXTENSIONS = ('*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff')
# 디렉토리 내 모든 이미지 파일 가져오기
image_files = []
for ext in IMAGE_EXTENSIONS:
    image_files.extend(glob.glob(os.path.join(IMAGE_DIR, ext)))
if not image_files:
    logging.error("지정된 디렉토리에 이미지 파일이 없습니다.")
    exit()
logging.info(f"총 {len(image_files)}개의 이미지를 처리합니다.")
# 클래스별 색상 매핑을 디렉토리 전체에서 일관되게 사용하기 위해 미리 생성
all_classes = set()
responses = {}
# 정상 제품 판정 기준 (대문자로 통일 및 오타 수정)
NORMAL_CRITERIA = {
    "RASPBERRY PICO": 1,
    "BOOTSEL": 1,
    "CHIPSET": 1,
    "OSCILLATOR": 1,
    "USB": 1,
    "HOLE": 4
}
def get_img(cam):
    """USB 카메라로부터 이미지를 캡처하여 반환합니다.
    Returns:
        numpy.array: 캡처된 이미지
    """
    ret, img = cam.read()
    if not ret:
        logging.error("카메라로부터 이미지를 캡처하지 못했습니다.")
        return None
    return img
def crop_img(img):
    """이미지를 지정된 영역으로 크롭하고 밝기를 조정합니다.
    Args:
        img (numpy.array): 원본 이미지
    Returns:
        numpy.array: 전처리된 이미지
    """
    size_dict = {"x": 800, "y": 380, "width": 400, "height": 550}
    x = size_dict["x"]
    y = size_dict["y"]
    w = size_dict["width"]
    h = size_dict["height"]
    img_cropped = img[y : y + h, x : x + w]
    # 밝기 조정
    img_bright = cv2.convertScaleAbs(img_cropped, alpha=1, beta=5)
    return img_bright
def save_img(img, save_dir, index):
    """이미지를 지정된 디렉토리에 저장합니다.
    Args:
        img (numpy.array): 저장할 이미지
        save_dir (str): 저장 디렉토리 경로
        index (int): 이미지 인덱스
    Returns:
        int: 다음 이미지 인덱스
    """
    image_path = os.path.join(save_dir, f"new{index}.jpg")
    cv2.imwrite(image_path, img)
    logging.info(f"저장된 이미지: {image_path}")
    return index + 1
def inference_request(img: np.array, api_url: str):
    """이미지를 API로 전송하여 추론을 요청합니다.
    Args:
        img (numpy.array): 추론할 이미지
        api_url (str): API 엔드포인트 URL
    Returns:
        dict: API 응답 JSON 또는 None
    """
    _, img_encoded = cv2.imencode(".jpg", img)
    img_bytes = BytesIO(img_encoded.tobytes())
    files = {"file": ("image.jpg", img_bytes, "image/jpeg")}
    logging.debug(f"보낼 파일: {files}")
    try:
        response = requests.post(api_url, files=files)
        if response.status_code == 200:
            response_json = response.json()
            logging.info(f"API 응답: {json.dumps(response_json, indent=4, ensure_ascii=False)}")
            return response_json
        else:
            logging.error(f"이미지 전송 실패. 상태 코드: {response.status_code}")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"요청 전송 중 오류 발생: {e}")
        return None
def annotate_image(image, response_json):
    """API 응답을 기반으로 이미지를 주석 처리합니다.
    Args:
        image (numpy.array): 원본 이미지
        response_json (dict): API 응답 JSON
    Returns:
        numpy.array: 주석이 추가된 이미지
    """
    if not response_json:
        logging.warning("주석 처리를 위한 API 응답이 없습니다.")
        return image
    objects = response_json.get('objects', [])
    if not objects:
        logging.info("객체가 감지되지 않았습니다.")
        return image
    class_counts = {}
    # Bounding Box 및 레이블 그리기
    for obj in objects:
        class_name = obj['class'].strip().upper()
        score = obj.get('score', 0.0)
        box = obj.get('box', [0, 0, 0, 0])
        x1, y1, x2, y2 = box
        # 클래스별 개수 카운트
        class_counts[class_name] = class_counts.get(class_name, 0) + 1
        # Bounding Box 그리기
        color = colors.get(class_name, (0, 255, 0))  # 기본 색상: 녹색
        thickness = 2
        cv2.rectangle(image, (x1, y1), (x2, y2), color, thickness)
        # 레이블 그리기
        label = f"{class_name}: {score:.2f}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.5
        font_thickness = 1
        text_size, _ = cv2.getTextSize(label, font, font_scale, font_thickness)
        text_w, text_h = text_size
        # 텍스트 배경 사각형
        cv2.rectangle(image, (x1, y1 - text_h - 4), (x1 + text_w, y1), color, -1)
        # 텍스트 그리기
        cv2.putText(image, label, (x1, y1 - 2), font, font_scale, (255, 255, 255), font_thickness, cv2.LINE_AA)
    # 클래스별 개수를 내림차순으로 정렬
    sorted_class_info = sorted(class_counts.items(), key=lambda item: item[1], reverse=True)
    class_info_lines = [f"{cls}: {count}" for cls, count in sorted_class_info]
    # 클래스 정보 텍스트 그리기
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    font_thickness = 2
    line_height = 20
    padding = 10
    # 텍스트 배경 사각형 크기 계산
    max_text_w = 0
    for line in class_info_lines:
        text_size, _ = cv2.getTextSize(line, font, font_scale, font_thickness)
        text_w, _ = text_size
        if text_w > max_text_w:
            max_text_w = text_w
    total_text_h = line_height * len(class_info_lines)
    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (padding - 5, padding - 5),
        (padding + max_text_w + 10, padding + total_text_h + 5),
        (0, 0, 0),  # 검은색
        -1
    )
    # 각 클래스별 정보 텍스트 그리기
    for idx, line in enumerate(class_info_lines):
        text_position = (padding, padding + (idx + 1) * line_height)
        cv2.putText(
            image,
            line,
            text_position,
            font,
            font_scale,
            (255, 255, 255),  # 흰색
            font_thickness,
            cv2.LINE_AA
        )
    # 정상 제품 판정
    is_normal = True
    for key, value in NORMAL_CRITERIA.items():
        detected = class_counts.get(key.upper(), 0)
        if detected != value:
            logging.warning(f"Mismatch for {key.upper()}: expected {value}, got {detected}")
            is_normal = False
            break
    # 정상 기준에 없는 클래스가 감지되었는지 확인
    if is_normal:
        for detected_class in class_counts.keys():
            if detected_class not in NORMAL_CRITERIA:
                logging.warning(f"Unexpected class detected: {detected_class}")
                is_normal = False
                break
    # 판정 결과 텍스트 및 색상 설정
    if is_normal:
        status_text = "normal"
        status_color = (0, 255, 0)  # 녹색
    else:
        status_text = "poor"
        status_color = (0, 0, 255)  # 빨간색
    # 판정 결과 텍스트 그리기
    status_font_scale = 1.0
    status_font_thickness = 2
    status_text_size, _ = cv2.getTextSize(status_text, font, status_font_scale, status_font_thickness)
    status_text_w, status_text_h = status_text_size
    # 이미지의 오른쪽 하단 좌표 계산
    image_height, image_width = image.shape[:2]
    status_padding = 10
    status_x = image_width - status_text_w - status_padding
    status_y = image_height - status_padding
    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (status_x - 5, status_y - status_text_h - 5),
        (status_x + status_text_w + 5, status_y + 5),
        status_color,
        -1
    )
    # 판정 결과 텍스트 그리기 (흰색 글씨)
    cv2.putText(
        image,
        status_text,
        (status_x, status_y),
        font,
        status_font_scale,
        (255, 255, 255),  # 흰색
        status_font_thickness,
        cv2.LINE_AA
    )
    return image
def main():
    # 카메라 초기화
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        logging.error("카메라를 열 수 없습니다.")
        exit(-1)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    image_index = 0
    while True:
        try:
            data = ser.read(1)  # 1바이트 읽기
            logging.info(f"받은 데이터: {data}")
            if data == b"0":
                # 이미지 캡처
                img = get_img(cam)
                if img is None:
                    continue
                # 이미지 전처리
                img_cropped = crop_img(img)
                # 원본 이미지 저장
                image_index = save_img(img_cropped, SAVE_DIR, image_index)
                # API 요청 및 응답 받기
                response = inference_request(img_cropped, api_url)
                # 이미지에 주석 추가
                annotated_img = annotate_image(img_cropped.copy(), response)
                # 주석 이미지 저장
                annotated_image_path = os.path.join(ANNOTATED_DIR, f"annotated_{image_index}.jpg")
                cv2.imwrite(annotated_image_path, annotated_img)
                logging.info(f"주석이 추가된 이미지 저장: {annotated_image_path}")
                # 이미지 디스플레이 (옵션)
                cv2.imshow("Annotated Image", annotated_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                # 시리얼로 응답 전송
                ser.write(b"1")
            else:
                pass
            # CPU 사용률을 낮추기 위한 짧은 대기
            time.sleep(0.1)
        except KeyboardInterrupt:
            logging.info("프로그램을 종료합니다.")
            break
        except Exception as e:
            logging.error(f"메인 루프 중 오류 발생: {e}")
    # 자원 해제
    cam.release()
    cv2.destroyAllWindows()
if __name__ == "__main__":
    main()