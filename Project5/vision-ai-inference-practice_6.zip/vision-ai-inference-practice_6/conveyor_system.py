import time
import threading
import queue
import serial
import requests
import numpy as np
import os
import cv2
import json
import logging
import random
from requests.auth import HTTPBasicAuth

# -------------------------------
# 1. 로깅 설정
# -------------------------------
logging.basicConfig(
    level=logging.INFO,  # DEBUG로 변경하면 더 상세한 로그 확인 가능
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("app.log", encoding='utf-8'),  # 로그 파일 (UTF-8 인코딩)
        logging.StreamHandler()                              # 콘솔 출력
    ]
)

# -------------------------------
# 2. API 설정
# -------------------------------
URL = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/f928ebdf-89bd-4611-9c8a-dc9fe2da0049/inference"
ACCESS_KEY = "NbeRrNlMV99thyzJbJJ4k5NqIKm61TQU9iXRfYRx"
USERNAME = "kdt2024_1-26"

# -------------------------------
# 3. 시리얼 포트 초기화
# -------------------------------
SERIAL_PORT = "/dev/ttyACM0"  # 필요에 따라 변경
BAUD_RATE = 9600

try:
    ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)  # 타임아웃 1초
    logging.info(f"시리얼 포트 {SERIAL_PORT}에 연결되었습니다.")
except serial.SerialException as e:
    logging.error(f"시리얼 포트 연결 실패: {e}")
    exit(1)

# -------------------------------
# 4. 디렉토리 설정
# -------------------------------
SAVE_DIR = "/home/rokey/vision-ai-inference-practice/save_dir"  # 원본 이미지 저장 디렉토리
ANNOTATED_DIR = "/home/rokey/vision-ai-inference-practice/annotate_dir"      # 주석 이미지 저장 디렉토리

# 디렉토리 생성
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(ANNOTATED_DIR, exist_ok=True)

# -------------------------------
# 5. 정상 제품 판정 기준
# -------------------------------
NORMAL_CRITERIA = {
    #"RASPBERRY PICO": 1,
    "BOOTSEL": 1,
    "CHIPSET": 1,
    "OSCILLATOR": 1,
    "USB": 1,
    "HOLE": 4
}

# -------------------------------
# 6. 함수 정의
# -------------------------------

def get_img(cam):
    """USB 카메라로부터 이미지를 캡처하여 반환합니다."""
    ret, img = cam.read()
    if not ret:
        logging.error("카메라로부터 이미지를 캡처하지 못했습니다.")
        return None
    return img

def crop_img(img):
    """이미지를 지정된 영역으로 크롭하고 밝기를 조정합니다."""
    size_dict = {"x": 800, "y": 380, "width": 400, "height": 550}
    x = size_dict["x"]
    y = size_dict["y"]
    w = size_dict["width"]
    h = size_dict["height"]
    img_cropped = img[y : y + h, x : x + w]
    # 밝기 조정
    img_bright = cv2.convertScaleAbs(img_cropped, alpha=1, beta=5)
    return img_bright

def save_img(img, save_dir, index):
    """이미지를 지정된 디렉토리에 저장합니다."""
    image_path = os.path.join(save_dir, f"new{index}.jpg")
    cv2.imwrite(image_path, img)
    logging.info(f"저장된 이미지: {image_path}")
    return index + 1

def inference_request(img: np.array, api_url: str):
    """이미지를 API로 전송하여 추론을 요청합니다.
    Args:
        img (numpy.array): 추론할 이미지
        api_url (str): API 엔드포인트 URL
    Returns:
        dict: API 응답 JSON 또는 None
    """
    try:
        # JPEG 인코딩
        _, img_encoded = cv2.imencode(".jpg", img)
        image_data = img_encoded.tobytes()

        # API 요청
        response = requests.post(
            url=api_url,
            auth=HTTPBasicAuth(USERNAME, ACCESS_KEY),
            headers={"Content-Type": "image/jpeg"},
            data=image_data
        )

        # 응답 상태 코드 로그
        logging.info(f"API 응답 상태 코드: {response.status_code}")

        if response.status_code == 200:
            response_json = response.json()
            logging.info(f"API 응답: {json.dumps(response_json, indent=4, ensure_ascii=False)}")
            return response_json
        else:
            logging.error(f"이미지 전송 실패. 상태 코드: {response.status_code}")
            logging.error(f"응답 내용: {response.text}")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"요청 전송 중 오류 발생: {e}")
        return None
    except Exception as e:
        logging.error(f"예기치 않은 오류 발생: {e}")
        return None

def annotate_image(image, response_json, colors, normal_criteria):
    """API 응답을 기반으로 이미지를 주석 처리합니다.
    Args:
        image (numpy.array): 원본 이미지
        response_json (dict): API 응답 JSON
        colors (dict): 클래스별 색상 매핑
        normal_criteria (dict): 정상 판정 기준
    Returns:
        numpy.array: 주석이 추가된 이미지
    """
    if not response_json:
        logging.warning("주석 처리를 위한 API 응답이 없습니다.")
        return image

    objects = response_json.get('objects', [])
    if not objects:
        logging.info("객체가 감지되지 않았습니다.")
        return image

    class_counts = {}
    # Bounding Box 및 레이블 그리기
    for obj in objects:
        class_name = obj['class'].strip().upper()
        score = obj.get('score', 0.0)
        box = obj.get('box', [0, 0, 0, 0])
        if len(box) != 4:
            logging.warning(f"잘못된 박스 좌표: {box}")
            continue
        x1, y1, x2, y2 = box

        # 클래스별 개수 카운트
        class_counts[class_name] = class_counts.get(class_name, 0) + 1

        # Bounding Box 그리기
        color = colors.get(class_name, (0, 255, 0))  # 기본 색상: 녹색
        thickness = 2
        cv2.rectangle(image, (x1, y1), (x2, y2), color, thickness)

        # 레이블 그리기
        label = f"{class_name}: {score:.2f}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.5
        font_thickness = 1
        text_size, _ = cv2.getTextSize(label, font, font_scale, font_thickness)
        text_w, text_h = text_size
        # 텍스트 배경 사각형
        cv2.rectangle(image, (x1, y1 - text_h - 4), (x1 + text_w, y1), color, -1)
        # 텍스트 그리기
        cv2.putText(image, label, (x1, y1 - 2), font, font_scale, (255, 255, 255), font_thickness, cv2.LINE_AA)

    # 클래스별 개수를 내림차순으로 정렬
    sorted_class_info = sorted(class_counts.items(), key=lambda item: item[1], reverse=True)
    class_info_lines = [f"{cls}: {count}" for cls, count in sorted_class_info]

    # 클래스 정보 텍스트 그리기
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    font_thickness = 2
    line_height = 20
    padding = 10

    # 텍스트 배경 사각형 크기 계산
    max_text_w = 0
    for line in class_info_lines:
        text_size, _ = cv2.getTextSize(line, font, font_scale, font_thickness)
        text_w, _ = text_size
        if text_w > max_text_w:
            max_text_w = text_w
    total_text_h = line_height * len(class_info_lines)

    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (padding - 5, padding - 5),
        (padding + max_text_w + 10, padding + total_text_h + 5),
        (0, 0, 0),  # 검은색
        -1
    )

    # 각 클래스별 정보 텍스트 그리기
    for idx, line in enumerate(class_info_lines):
        text_position = (padding, padding + (idx + 1) * line_height)
        cv2.putText(
            image,
            line,
            text_position,
            font,
            font_scale,
            (255, 255, 255),  # 흰색
            font_thickness,
            cv2.LINE_AA
        )

    # 정상 제품 판정
    is_normal = True
    for key, value in normal_criteria.items():
        detected = class_counts.get(key.upper(), 0)
        if detected != value:
            logging.warning(f"불일치 감지 - {key.upper()}: 예상 {value}, 실제 {detected}")
            is_normal = False
            break
    # 정상 기준에 없는 클래스가 감지되었는지도 확인
    """
    if is_normal:
        for detected_class in class_counts.keys():
            if detected_class not in normal_criteria:
                logging.warning(f"예상치 못한 클래스 감지: {detected_class}")
                is_normal = False
                break
"""
    # 판정 결과 텍스트 및 색상 설정
    if is_normal:
        status_text = "Normal"
        status_color = (0, 255, 0)  # 녹색
    else:
        status_text = "Poor"
        status_color = (0, 0, 255)  # 빨간색

    # 판정 결과 텍스트 그리기
    status_font_scale = 1.0
    status_font_thickness = 2
    status_text_size, _ = cv2.getTextSize(status_text, font, status_font_scale, status_font_thickness)
    status_text_w, status_text_h = status_text_size

    # 이미지의 오른쪽 하단 좌표 계산
    image_height, image_width = image.shape[:2]
    status_padding = 10
    status_x = image_width - status_text_w - status_padding
    status_y = image_height - status_padding

    # 텍스트 배경 사각형 그리기
    cv2.rectangle(
        image,
        (status_x - 5, status_y - status_text_h - 5),
        (status_x + status_text_w + 5, status_y + 5),
        status_color,
        -1
    )

    # 판정 결과 텍스트 그리기 (흰색 글씨)
    cv2.putText(
        image,
        status_text,
        (status_x, status_y),
        font,
        status_font_scale,
        (255, 255, 255),  # 흰색
        status_font_thickness,
        cv2.LINE_AA
    )

    return image

# -------------------------------
# 7. 스레드 함수 정의
# -------------------------------

def capture_thread(cam, image_queue, stop_event):
    """컨베이어 벨트 제어 및 이미지 캡처 스레드."""
    image_index = 0
    while not stop_event.is_set():
        try:
            data = ser.read(1)  # 1바이트 읽기
            if data == b"0":
                logging.info("트리거 신호 수신: 이미지 캡처 시작.")

                time.sleep(0.5)

                img = get_img(cam)
                if img is None:
                    continue
                img_cropped = crop_img(img)
                image_index = save_img(img_cropped, SAVE_DIR, image_index)
                # 이미지와 인덱스를 큐에 넣기
                image_queue.put((img_cropped, image_index))
                logging.info(f"이미지 {image_index} 처리를 위해 큐에 추가됨.")
            else:
                pass  # 다른 데이터는 무시
            #time.sleep(0.1)  # CPU 사용률 낮추기 위한 짧은 대기
        except Exception as e:
            logging.error(f"캡처 스레드 오류: {e}")

def processing_thread(image_queue, api_url, colors, normal_criteria, annotated_dir, stop_event):
    """API 통신 및 이미지 주석 처리 스레드."""
    while not stop_event.is_set() or not image_queue.empty():
        try:
            img, index = image_queue.get(timeout=1)  # 큐에서 이미지 가져오기 (타임아웃 1초)
        except queue.Empty:
            continue  # 큐가 비어있으면 다시 시도
        try:
            logging.info(f"이미지 {index} 처리: API로 전송 중.")
            response = inference_request(img, api_url)
            if response and 'objects' in response:
                # 클래스별 색상 매핑 업데이트
                for obj in response['objects']:
                    class_name = obj['class'].strip().upper()
                    if class_name not in colors:
                        colors[class_name] = tuple(random.randint(0, 255) for _ in range(3))
            else:
                logging.warning(f"API 응답에 'objects'가 없습니다. 이미지 {index}는 불량으로 간주됩니다.")
            # 이미지에 주석 추가
            annotated_img = annotate_image(img.copy(), response, colors, normal_criteria)
            # 주석 이미지 저장
            annotated_image_path = os.path.join(annotated_dir, f"annotated_{index}.jpg")
            cv2.imwrite(annotated_image_path, annotated_img)
            logging.info(f"주석이 추가된 이미지 저장됨: {annotated_image_path}")
            # 시리얼 포트로 응답 전송
            ser.write(b"1")
            logging.info(f"이미지 {index}에 대한 응답 '1' 전송 완료.")
            # 이미지 디스플레이 (옵션)
            cv2.imshow("Annotated Image", annotated_img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                logging.info("종료 신호 수신: 프로그램 종료 준비.")
                stop_event.set()
                break
        except Exception as e:
            logging.error(f"처리 스레드 오류 (이미지 {index}): {e}")
        finally:
            image_queue.task_done()

# -------------------------------
# 8. 메인 함수 정의
# -------------------------------
def main():
    # 카메라 초기화
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        logging.error("카메라를 열 수 없습니다.")
        exit(-1)
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    logging.info("카메라 초기화 완료.")

    # 색상 매핑 딕셔너리 초기화
    colors = {}

    # 스레드 간 이미지 전달을 위한 큐 초기화
    image_queue = queue.Queue()

    # 스레드 종료를 위한 이벤트 초기화
    stop_event = threading.Event()

    # 스레드 1: 컨베이어 벨트 제어 및 이미지 캡처
    capture = threading.Thread(target=capture_thread, args=(cam, image_queue, stop_event), daemon=True)
    capture.start()
    logging.info("캡처 스레드 시작됨.")

    # 스레드 2: API 통신 및 이미지 주석 처리
    processing = threading.Thread(target=processing_thread, args=(image_queue, URL, colors, NORMAL_CRITERIA, ANNOTATED_DIR, stop_event), daemon=True)
    processing.start()
    logging.info("처리 스레드 시작됨.")

    try:
        while True:
            time.sleep(1)  # 메인 스레드는 무한 루프를 유지
    except KeyboardInterrupt:
        logging.info("KeyboardInterrupt 수신: 프로그램 종료 준비.")
        stop_event.set()

    # 큐가 비어질 때까지 대기
    image_queue.join()

    # 자원 해제
    cam.release()
    ser.close()
    cv2.destroyAllWindows()
    logging.info("프로그램이 정상적으로 종료되었습니다.")

if __name__ == "__main__":
    main()
