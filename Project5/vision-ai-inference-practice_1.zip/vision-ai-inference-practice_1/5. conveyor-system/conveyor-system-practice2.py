import time
import serial
import requests
from requests.auth import HTTPBasicAuth
import numpy as np
from io import BytesIO
import cv2
import os
from collections import Counter
import random
import threading
import queue
import logging

# ------------------------------
# Setup Logging
# ------------------------------
logging.basicConfig(
    filename='conveyor_system.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s:%(message)s'
)

# ------------------------------
# 1. Class Color Mapping and Dynamic Color Generation
# ------------------------------
# Initial class color mapping (can be changed as desired)
class_colors = {
    'RASPBERRY PICO': (255, 0, 0),    # Blue
    'USB': (0, 255, 0),               # Green
    'OSCILLATOR': (0, 0, 255),        # Red
    'HOLE': (255, 255, 0),            # Cyan
    'CHIPSET': (255, 0, 255),         # Magenta
    'BOOTSEL': (0, 255, 255)          # Yellow
}

def get_class_color(class_name):
    """
    Returns the color based on the class name.
    Generates a random color and adds it if a new class is encountered.
    """
    if class_name in class_colors:
        return class_colors[class_name]
    else:
        # Generate random color
        color = tuple(random.randint(0, 255) for _ in range(3))
        class_colors[class_name] = color
        return color

# ------------------------------
# 2. Draw Legend Function
# ------------------------------
def draw_legend(img, class_counts, font, font_scale, text_thickness):
    """
    Draws a legend on the image displaying the count of each class.
    """
    box_size = 20
    padding = 5
    margin = 10

    num_classes = len(class_counts)
    legend_height = num_classes * (box_size + padding) + padding
    legend_width = 0
    for class_name, count in class_counts.items():
        label = f"{class_name} ({count})"
        (text_width, text_height), baseline = cv2.getTextSize(label, font, font_scale, text_thickness)
        if text_width + box_size + 3 * padding > legend_width:
            legend_width = text_width + box_size + 3 * padding
    legend_width += margin  # Additional margin

    # Draw legend background rectangle (white)
    legend_bg_start = (margin, margin)
    legend_bg_end = (margin + int(legend_width), margin + int(legend_height))
    cv2.rectangle(img, legend_bg_start, legend_bg_end, (255, 255, 255), cv2.FILLED)

    # Draw legend items
    current_y = margin + padding
    for class_name, count in class_counts.items():
        color = get_class_color(class_name)
        label = f"{class_name} ({count})"

        # Draw color box
        box_start = (margin + padding, current_y)
        box_end = (margin + padding + box_size, current_y + box_size)
        cv2.rectangle(img, box_start, box_end, color, cv2.FILLED)

        # Draw text
        text_position = (margin + padding + box_size + padding, current_y + box_size - 5)
        cv2.putText(img, label, text_position, font, font_scale, (0, 0, 0), text_thickness, cv2.LINE_AA)

        # Adjust y position for next item
        current_y += box_size + padding

# ------------------------------
# 3. Get Box Data from API
# ------------------------------
def get_box_data_from_api(image_data, url, username, access_key, retries=3):
    """
    Sends the image to the API and retrieves box data.
    Implements retry logic for robustness.
    """
    for attempt in range(retries):
        try:
            response = requests.post(
                url=url,
                auth=HTTPBasicAuth(username, access_key),
                headers={"Content-Type": "image/jpeg"},
                data=image_data,
                timeout=10  # Timeout after 10 seconds
            )

            response.raise_for_status()  # Raise exception for HTTP errors

            return response.json().get("objects", [])
        except Exception as e:
            logging.error(f"API request error (Attempt {attempt+1}/{retries}): {e}")
            time.sleep(2)  # Wait before retrying
    return []

# ------------------------------
# 4. Draw Boxes on Image
# ------------------------------
def draw_boxes_on_image(img, boxes, font, font_scale, text_thickness, confidence_threshold):
    """
    Draws bounding boxes and labels on the image based on detected objects.
    """
    occupied_text_regions = []
    class_counts = Counter(obj['class'] for obj in boxes if obj['score'] >= confidence_threshold)

    for obj in boxes:
        class_name = obj['class']
        score = obj['score']
        box = obj['box']  # [x1, y1, x2, y2]

        if score < confidence_threshold:
            continue

        start_point = (box[0], box[1])  # Top-left (x1, y1)
        end_point = (box[2], box[3])    # Bottom-right (x2, y2)

        color = get_class_color(class_name)
        thickness = 2  # Line thickness

        # Draw bounding box
        cv2.rectangle(img, start_point, end_point, color, thickness)

        # Prepare label (class name and score)
        label = f"{class_name}: {score:.2f}"

        # Calculate text size
        (text_width, text_height), baseline = cv2.getTextSize(label, font, font_scale, text_thickness)

        # Determine text background position
        text_bg_x1 = start_point[0]
        text_bg_y1 = start_point[1] - text_height - 10
        if text_bg_y1 < 0:
            text_bg_y1 = start_point[1] + text_height + 10
        text_bg_x2 = start_point[0] + text_width + 4
        text_bg_y2 = text_bg_y1 + text_height + 10
        text_bg_start = (text_bg_x1, text_bg_y1)
        text_bg_end = (text_bg_x2, text_bg_y2)

        # Draw text background rectangle
        cv2.rectangle(img, text_bg_start, text_bg_end, color, cv2.FILLED)

        # Set text position
        text_position = (text_bg_start[0] + 2, text_bg_end[1] - 5)

        # Draw text (white)
        cv2.putText(img, label, text_position, font, font_scale, (255, 255, 255), text_thickness, cv2.LINE_AA)

        # Save occupied text region
        occupied_text_regions.append((text_bg_start[0], text_bg_start[1],
                                      text_bg_x2 - text_bg_x1, text_bg_y2 - text_bg_y1))

    # Draw legend
    draw_legend(img, class_counts, font, font_scale, text_thickness)

    return img

# ------------------------------
# 5. Image Processing Worker
# ------------------------------
def image_processing_worker(task_queue, result_queue, api_config, output_dir, font, font_scale, text_thickness, confidence_threshold):
    """
    Worker thread for processing images: sends to API, draws boxes, and saves the image.
    """
    url, username, access_key = api_config
    image_counter = 1

    while True:
        task = task_queue.get()
        if task is None:
            break  # Exit signal

        img = task
        logging.info("Processing image...")

        # Encode image to JPEG
        _, img_encoded = cv2.imencode('.jpg', img)
        image_data = img_encoded.tobytes()

        # Send to API
        boxes = get_box_data_from_api(image_data, url, username, access_key)

        if not boxes:
            logging.info("No objects detected.")
        else:
            # Draw boxes and labels
            img_with_boxes = draw_boxes_on_image(img, boxes, font, font_scale, text_thickness, confidence_threshold)

            # Save image
            image_name = f"captured_image_{image_counter}.jpg"
            output_path = os.path.join(output_dir, image_name)
            cv2.imwrite(output_path, img_with_boxes)
            logging.info(f"Image saved: {output_path}")
            image_counter += 1

        task_queue.task_done()

# ------------------------------
# 6. Main Function with Multithreading
# ------------------------------
def main():
    # Serial communication setup
    serial_port = "/dev/ttyACM0"
    baud_rate = 9600

    try:
        ser = serial.Serial(serial_port, baud_rate, timeout=1)
        logging.info(f"Opened serial port: {serial_port} at {baud_rate} baud.")
    except Exception as e:
        logging.error(f"Failed to open serial port {serial_port}: {e}")
        return

    # Camera initialization
    cam = cv2.VideoCapture(0)
    if not cam.isOpened():
        logging.error("Cannot open camera.")
        ser.close()
        return
    logging.info("Camera initialized successfully.")

    # API configuration
    URL = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/5e220579-46c5-4686-aa93-ca520529a7bc/inference"
    USERNAME = "kdt2024_1-26"  # API username
    ACCESS_KEY = "NbeRrNlMV99thyzJbJJ4k5NqIKm61TQU9iXRfYRx"  # API access key

    api_config = (URL, USERNAME, ACCESS_KEY)

    # Image saving directory
    OUTPUT_DIR = "/home/rokey/vision-ai-inference-practice/result_image"
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    logging.info(f"Image saving directory set to: {OUTPUT_DIR}")

    # Font settings
    font = cv2.FONT_HERSHEY_COMPLEX_SMALL
    font_scale = 0.5
    text_thickness = 1

    # Confidence threshold
    confidence_threshold = 0.3

    # Queues for threading
    task_queue = queue.Queue()
    result_queue = queue.Queue()

    # Start image processing thread
    processing_thread = threading.Thread(
        target=image_processing_worker,
        args=(task_queue, result_queue, api_config, OUTPUT_DIR, font, font_scale, text_thickness, confidence_threshold),
        daemon=True
    )
    processing_thread.start()
    logging.info("Image processing thread started.")

    try:
        while True:
            try:
                data = ser.readline().decode().strip()
                if data:
                    logging.info(f"Received data: {data}")
                if data == "0":
                    # Send stop signal to conveyor belt (modify as needed)
                    ser.write(b"STOP\n")
                    logging.info("Sent STOP signal to conveyor belt.")

                    # Capture image
                    ret, img = cam.read()
                    if not ret:
                        logging.error("Failed to capture image.")
                        ser.write(b"START\n")  # Attempt to restart conveyor
                        logging.info("Sent START signal to conveyor belt.")
                        continue

                    # Enqueue image for processing
                    task_queue.put(img)
                    logging.info("Image enqueued for processing.")

                    # Send start signal to conveyor belt (modify as needed)
                    ser.write(b"START\n")
                    logging.info("Sent START signal to conveyor belt.")

            except serial.SerialException as e:
                logging.error(f"Serial communication error: {e}")
                break
            except Exception as e:
                logging.error(f"Unexpected error: {e}")

            # Optional: Adjust sleep time as needed
            time.sleep(0.1)

    except KeyboardInterrupt:
        logging.info("Program interrupted by user.")

    finally:
        # Clean up
        ser.close()
        cam.release()
        # Signal the processing thread to exit
        task_queue.put(None)
        processing_thread.join()
        logging.info("Resources have been cleaned up. Program terminated.")

if __name__ == "__main__":
    main()