import cv2 as cv
import numpy as np

# 영상 경로를 제공해주세요.
video_file = '/home/parkseongho/turtlebot4_ws/turtlebot4/IMG_0094.MOV'

# ORB 객체 생성
orb = cv.ORB_create()

# 비디오 캡처 객체 생성
cap = cv.VideoCapture(video_file)
if not cap.isOpened():
    print("영상 로드 실패")
    cap.release()
    exit()

# FPS 기반 대기 시간 계산
fps = cap.get(cv.CAP_PROP_FPS)
original_delay = int(1000 / fps)
current_delay = original_delay

print(f"영상 FPS: {fps:.2f}, 원래 대기 시간: {original_delay}ms")

# 첫 번째 프레임 읽기
ret, prev_frame = cap.read()
if not ret:
    print("첫 번째 프레임 로드 실패")
    cap.release()
    exit()

# 첫 번째 프레임을 그레이스케일로 변환
prev_gray = cv.cvtColor(prev_frame, cv.COLOR_BGR2GRAY)

# ORB를 사용하여 초기 특징점 검출
kp = orb.detect(prev_gray, None)
prev_pts = np.array([kp_.pt for kp_ in kp], dtype=np.float32).reshape(-1, 1, 2)

# 주기적으로 ORB를 재실행할 설정
refresh_rate = 10  # 매 10번째 프레임마다 ORB 재실행
frame_count = 0

print("명령어:")
print("  - '1': 원래 속도")
print("  - '2': 느린 속도 (1/2)")
print("  - '3': 빠른 속도 (2배)")
print("  - 'q': 종료")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # 현재 프레임을 그레이스케일로 변환
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)

    # Optical Flow를 사용하여 기존 특징점 추적
    if len(prev_pts) > 0:
        next_pts, status, _ = cv.calcOpticalFlowPyrLK(prev_gray, gray, prev_pts, None)

        # 유효한 추적된 특징점 선택
        good_prev_pts = prev_pts[status.flatten() == 1]
        good_next_pts = next_pts[status.flatten() == 1]

        # 현재 상태를 다음 루프를 위한 이전 상태로 업데이트
        prev_pts = good_next_pts.reshape(-1, 1, 2)

    # 주기적으로 ORB를 재실행하여 새로운 특징점 추가
    if frame_count % refresh_rate == 0:
        kp = orb.detect(gray, None)
        new_pts = np.array([kp_.pt for kp_ in kp], dtype=np.float32).reshape(-1, 1, 2)

        # 기존 추적 점들과 병합
        if len(prev_pts) > 0:
            prev_pts = np.vstack((prev_pts, new_pts))
        else:
            prev_pts = new_pts

    # 추적된 특징점 표시
    for pt in prev_pts:
        x, y = pt.ravel()
        cv.circle(frame, (int(x), int(y)), 5, (0, 255, 0), -1)

    # 현재 프레임 표시
    cv.imshow('ORB Feature Tracking', frame)

    # 키 입력 처리
    key = cv.waitKey(current_delay) & 0xFF
    if key == ord('q'):  # 'q'를 누르면 종료
        break
    elif key == ord('1'):  # 원래 속도
        current_delay = original_delay
        print("속도: 원래 속도")
    elif key == ord('2'):  # 느린 속도 (1/2)
        current_delay = original_delay * 2
        print("속도: 느린 속도 (1/2)")
    elif key == ord('3'):  # 빠른 속도 (2배)
        current_delay = max(original_delay // 2, 1)  # 최소 대기 시간은 1ms
        print("속도: 빠른 속도 (2배)")

    # 이전 프레임 업데이트
    prev_gray = gray.copy()
    frame_count += 1

# 리소스 해제
cap.release()
cv.destroyAllWindows()
