import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped, Twist
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from action_msgs.msg import GoalStatus
import numpy as np
from scipy.ndimage import binary_dilation
import math
from tf2_ros import TransformListener, Buffer
from geometry_msgs.msg import TransformStamped
from sklearn.cluster import DBSCAN 
import os
import subprocess

class AutoExplorer(Node):
    def __init__(self):
        super().__init__('auto_explorer')
        # 로깅 수준 설정
        self.get_logger().set_level(rclpy.logging.LoggingSeverity.DEBUG)

        # 맵 구독자 설정
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.map_subscription = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.map_callback,
            qos_profile)
        self.map_subscription  # 사용되지 않는 변수 경고 방지

        # 네비게이션 액션 클라이언트 설정
        self.nav_action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # TF 리스너 설정
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.current_goal = None
        self._goal_handle = None  # 목표 핸들을 저장하기 위한 변수 추가
        self.map_data = None
        self.map_info = None
        self.exploration_complete = False

        # 탐색 시작 시간 기록
        self.start_time = self.get_clock().now()

        # 주기적으로 목표 지점을 업데이트하기 위한 타이머 설정 (예: 2초마다)
        self.update_timer = self.create_timer(6.0, self.update_goal)

        # 목표 지점까지의 거리 설정 (예: 1.0미터 앞)
        self.goal_distance = 1.0

        # /cmd_vel 퍼블리셔 추가 (신뢰성 있는 QoS 사용)
        cmd_vel_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.cmd_vel_publisher = self.create_publisher(Twist, '/cmd_vel', cmd_vel_qos)

        # 로봇을 멈추기 위한 플래그 및 타이머 설정
        self.stop_robot = False
        self.stop_timer = self.create_timer(0.05, self.publish_stop_twist)  # 50Hz

    def map_callback(self, msg):
        self.map_data = np.array(msg.data, dtype=np.int8)
        self.map_info = msg.info
        self.get_logger().debug(f'Map received: width={self.map_info.width}, height={self.map_info.height}')
        if not self.exploration_complete:
            self.process_map()

    def process_map(self):
        # 맵 데이터를 2D 배열로 변환
        width = self.map_info.width
        height = self.map_info.height
        map_2d = self.map_data.reshape((height, width))

        # 전체 셀 수
        total_cells = width * height

        # 현재 시간과 시작 시간의 경과 시간 계산
        now = self.get_clock().now()
        elapsed_time = (now - self.start_time).nanoseconds / 1e9  # 초 단위

        self.get_logger().debug(f'Elapsed time: {elapsed_time:.2f} seconds')

        if elapsed_time < 180.0:
            self.get_logger().debug('탐색 시작 후 3분이 지나지 않았습니다. 탐색 완료 조건을 평가하지 않습니다.')
            return  # 3분이 지나지 않았으므로 프론티어 비율 평가를 건너뜁니다.

        # 탐색된 영역과 미탐색 영역의 경계선 찾기 (프론티어 셀)
        frontier_indices = self.find_frontiers(map_2d)
        num_frontier_cells = len(frontier_indices) if frontier_indices is not None else 0

        # 프론티어 셀의 비율 계산
        frontier_ratio = num_frontier_cells / total_cells
        self.get_logger().debug(f'Number of frontier cells: {num_frontier_cells}, Total cells: {total_cells}, Frontier ratio: {frontier_ratio:.5f}')

        # 프론티어 비율이 특정 임계값 이하일 경우 탐색 완료로 판단
        if frontier_ratio <= 0.00003:
            if not self.exploration_complete:
                self.exploration_complete = True
                self.get_logger().info('탐색이 완료되었습니다! 맵을 저장합니다...')
                self.save_map()
            return

        if frontier_indices is not None and len(frontier_indices) > 0:
            # 목표 지점 계산
            goal_point = self.calculate_goal(frontier_indices)
            if goal_point is not None:
                self.get_logger().debug(f'Sending goal: {goal_point}')
                self.send_goal(goal_point)
        else:
            # 프론티어가 없으면 탐색 완료로 판단
            if not self.exploration_complete:
                self.exploration_complete = True
                self.get_logger().info('탐색이 완료되었습니다! 맵을 저장합니다...')
                self.save_map()

    def find_frontiers(self, map_2d):
        # 탐색된 셀(자유 공간)
        free_space = (map_2d == 0)
        # 미탐색 셀
        unknown_space = (map_2d == -1)
        # 벽
        wall = (map_2d==100)

        dilated_free_space = binary_dilation(free_space)
        dilated_wall = binary_dilation(wall, iterations=2)
        frontiers = np.logical_and(np.logical_and(dilated_free_space, unknown_space), np.logical_not(dilated_wall))
        frontier_indices = np.argwhere(frontiers)
        self.get_logger().debug(f'Frontier indices found: {frontier_indices.shape[0]}')
        if frontier_indices.size == 0:
            return None
        else:
            return frontier_indices

    def calculate_goal(self, frontier_indices):
        try:
            # 로봇의 현재 위치 얻기
            now = rclpy.time.Time()
            trans = self.tf_buffer.lookup_transform('map', 'base_link', now)
            robot_x = trans.transform.translation.x
            robot_y = trans.transform.translation.y
            self.get_logger().debug(f'Robot position: x={robot_x}, y={robot_y}')
            # 프론티어 인덱스를 x, y 좌표로 변환
            map_coords = frontier_indices[:, [1, 0]]  # [x, y] 순서로 변경
            world_coords = map_coords * self.map_info.resolution
            world_coords[:, 0] += self.map_info.origin.position.x
            world_coords[:, 1] += self.map_info.origin.position.y
            # 프론티어 클러스터링
            if len(world_coords) == 0:
                self.get_logger().debug('No world coordinates available for clustering.')
                return None

            clustering = DBSCAN(eps=0.5, min_samples=5).fit(world_coords)
            labels = clustering.labels_
            # 각 클러스터의 중심점 계산
            unique_labels = set(labels)
            centroids = []
            for label in unique_labels:
                if label == -1:
                    continue  # 노이즈로 간주되는 포인트 제외
                class_member_mask = (labels == label)
                cluster_points = world_coords[class_member_mask]
                centroid = np.mean(cluster_points, axis=0)
                centroids.append(centroid)
            self.get_logger().debug(f'Centroids found: {len(centroids)}')
            if not centroids:
                return None
            # 로봇과 각 중심점 사이의 거리 계산
            distances = [math.hypot(c[0] - robot_x, c[1] - robot_y) for c in centroids]
            # 가장 가까운 중심점을 목표 지점으로 선택
            min_distance = min(distances)
            min_index = distances.index(min_distance)
            goal_x, goal_y = centroids[min_index]
            self.get_logger().debug(f'Goal point selected: x={goal_x}, y={goal_y}')
            return (goal_x, goal_y)
        except Exception as e:
            self.get_logger().error(f'목표 지점 계산 중 오류: {e}')
            return None

    def is_goal_valid(self, goal_x, goal_y):
        # 목표 지점의 유효성을 검사하는 함수
        # 여기서는 간단히 True를 반환하지만, 필요에 따라 추가 검사를 할 수 있습니다.
        return True

    def is_goal_in_front(self, goal_x, goal_y):
        # 시야각 제한을 제거하여 모든 방향의 목표를 허용
        return True

    def normalize_angle(self, angle):
        return math.atan2(math.sin(angle), math.cos(angle))

    def euler_from_quaternion(self, q):
        """
        쿼터니언을 오일러 각도(롤, 피치, 요)로 변환하는 함수
        """
        x = q.x
        y = q.y
        z = q.z
        w = q.w
        # 롤 (x축 회전)
        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        # 피치 (y축 회전)
        sinp = 2 * (w * y - z * x)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        # 요 (z축 회전)
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return roll, pitch, yaw

    def update_goal(self):
        if self.exploration_complete:
            self.get_logger().debug('Exploration complete. No new goals will be sent.')
            return
        try:
            # 로봇의 현재 위치와 방향 얻기
            now = rclpy.time.Time()
            trans = self.tf_buffer.lookup_transform('map', 'base_link', now)
            robot_x = trans.transform.translation.x
            robot_y = trans.transform.translation.y
            q = trans.transform.rotation
            _, _, yaw = self.euler_from_quaternion(q)
            # 목표 지점 계산 (현재 위치에서 진행 방향으로 일정 거리 앞)
            goal_x = robot_x + self.goal_distance * math.cos(yaw)
            goal_y = robot_y + self.goal_distance * math.sin(yaw)
            # 목표 지점이 유효한지 확인
            if self.is_goal_valid(goal_x, goal_y):
                self.get_logger().debug(f'Sending updated goal: x={goal_x}, y={goal_y}')
                self.send_goal((goal_x, goal_y))
        except Exception as e:
            self.get_logger().error(f'목표 지점 업데이트 중 오류: {e}')

    def send_goal(self, goal_point):
        self.get_logger().debug(f'Attempting to send goal: {goal_point}')
        if self.current_goal is not None and self._goal_handle is not None:
            # 현재 목표 지점을 취소하고 새로운 목표로 설정
            self.cancel_current_goal()
        # 새로운 목표 전송
        self.current_goal = goal_point
        goal_msg = PoseStamped()
        goal_msg.header.frame_id = 'map'
        goal_msg.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.position.x = goal_point[0]
        goal_msg.pose.position.y = goal_point[1]
        goal_msg.pose.orientation.w = 1.0  # 방향 유지
        self.get_logger().info(f'목표 전송: x={goal_point[0]:.2f}, y={goal_point[1]:.2f}')
        self.nav_action_client.wait_for_server()
        goal = NavigateToPose.Goal()
        goal.pose = goal_msg
        self._send_goal_future = self.nav_action_client.send_goal_async(
            goal, feedback_callback=self.feedback_callback)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def cancel_current_goal(self):
        if self.current_goal is not None and self._goal_handle is not None:
            # 목표를 취소하기 위해 목표 핸들의 cancel_goal_async() 메서드 사용
            cancel_future = self._goal_handle.cancel_goal_async()
            cancel_future.add_done_callback(self.cancel_done)
            self.current_goal = None

    def cancel_done(self, future):
        cancel_response = future.result()
        if len(cancel_response.goals_canceling) > 0:
            self.get_logger().info('현재 목표를 성공적으로 취소했습니다.')
        else:
            self.get_logger().info('현재 목표 취소에 실패했습니다.')

    def feedback_callback(self, feedback_msg):
        # 선택 사항: 피드백 처리
        pass

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('목표가 서버에서 거부되었습니다.')
            self.current_goal = None
            self._goal_handle = None  # 목표 핸들 초기화
            return
        self.get_logger().info('목표가 서버에서 수락되었습니다.')
        self._goal_handle = goal_handle  # 목표 핸들 저장
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result()
        status = result.status
        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info('목표에 성공적으로 도달했습니다!')
        else:
            self.get_logger().warn(f'목표 실패, 상태 코드: {status}')
        self.current_goal = None
        self._goal_handle = None  # 목표 핸들 초기화

    def save_map(self):
        try:
            self.get_logger().info('save_map 메서드 호출됨.')
            # 맵을 저장할 디렉토리 지정 (절대 경로 사용)
            save_dir = '/home/rokey/ij3/maps'  # 원하는 절대 경로로 변경
            os.makedirs(save_dir, exist_ok=True)  # 디렉토리가 없으면 생성

            # nav2_map_server를 사용하여 맵 저장
            map_save_command = [
                'ros2', 'run', 'nav2_map_server', 'map_saver_cli',
                '-f', f'{save_dir}/turtlebot4_map'  # 저장할 파일 경로 및 이름
            ]
            # 명령어 실행 및 결과 캡처
            result = subprocess.run(map_save_command, capture_output=True, text=True)
            if result.returncode == 0:
                self.get_logger().info(f'맵이 {save_dir} 디렉토리에 성공적으로 저장되었습니다.')
                # 로봇 정지
                self.cancel_current_goal()  # 현재 목표 취소
                self.stop_robot = True  # Stop publishing zero Twist
                self.update_timer.cancel()  # Stop sending new goals
                self.get_logger().info('맵 저장 후 로봇을 멈췄습니다.')
            else:
                self.get_logger().error(f'맵 저장 실패: {result.stderr}')
        except Exception as e:
            self.get_logger().error(f'맵 저장 중 오류: {e}')

    def publish_stop_twist(self):
        if self.stop_robot:
            stop_twist = Twist()
            # 모든 선형 속도를 0으로 설정
            stop_twist.linear.x = 0.0
            stop_twist.linear.y = 0.0
            stop_twist.linear.z = 0.0
            # 모든 각속도를 0으로 설정
            stop_twist.angular.x = 0.0
            stop_twist.angular.y = 0.0
            stop_twist.angular.z = 0.0
            # 여러 번 퍼블리시하여 확실히 멈춤
            for _ in range(10):  # 필요에 따라 반복 횟수 조정
                self.cmd_vel_publisher.publish(stop_twist)
            self.get_logger().debug('모든 축이 0으로 설정된 Twist 메시지 10번 퍼블리시됨.')

    def get_current_pose(self):
        try:
            trans = self.tf_buffer.lookup_transform(
                'map', 'base_link', rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.5))
            robot_x = trans.transform.translation.x
            robot_y = trans.transform.translation.y
            self.get_logger().debug(f'Current Pose: x={robot_x}, y={robot_y}')
            return robot_x, robot_y
        except Exception as e:
            self.get_logger().error(f'현재 위치를 가져오는 데 실패: {e}')
            return None, None

def main(args=None):
    rclpy.init(args=args)
    auto_explorer = AutoExplorer()
    rclpy.spin(auto_explorer)
    auto_explorer.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()