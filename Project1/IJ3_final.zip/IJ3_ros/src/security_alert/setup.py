from setuptools import find_packages, setup

package_name = 'security_alert'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='moon0',
    maintainer_email='moon0@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'detection = security_alert.detection:main' ,
            'yolo_detection = security_alert.yolo_detection:main' , 
            'display = security_alert.display_node:main' ,
            'image = security_alert.image_publisher:main' ,
            'flask = security_alert.flask_node:main' ,
            'flask_pub = security_alert.flask_pub:main' ,
            'flask2_pub = security_alert.flask2_pub:main' ,
            'system = security_alert.system_monitor:main' ,
            'db1 = security_alert.db_pub:main' ,
            'db2 = security_alert.db_sub:main' ,
            'db3 = security_alert.db_sub2:main' ,
            'app = security_alert.app:main' ,
            'amr1 = security_alert.amr_pub:main' ,
            'amr2 = security_alert.amr_sub:main' ,
            'pub1 = security_alert.security_pub:main',
            'sub1 = security_alert.security_sub:main' ,
            'nav = security_alert.amr_:main' 
            

        ],
    },
)
