import cv2
import rclpy
import numpy as np
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import sqlite3
import json
from datetime import datetime  # datetime 모듈을 사용하여 타임스탬프를 추가

class DetectionSubscriberNode(Node):
    def __init__(self):
        super().__init__('detection_subscriber_node')
        self.bridge = CvBridge()
        self.image = None
    
        self.detection_sub = self.create_subscription(
            String,
            'amr/detections',  # 객체 탐지 정보를 퍼블리시하는 토픽
            self.amr_listener_callback,  # 콜백 함수
            10
        )
        self.image_sub = self.create_subscription(
            Image,
            'amr/image',
            self.amr_image_callback1,
            10
        )
        self.detection_sub  # 객체를 유지하여 구독을 활성화

        # SQLite3 데이터베이스 연결
        self.conn = sqlite3.connect('/home/moon0/IJ3_ros/src/security_alert/security_alert/amr_detection.db')  # 절대 경로 사용
        self.cursor = self.conn.cursor()
        self.create_table()

    def amr_image_callback1(self, msg) :
        global amr_latest_frame
        try:
            self.image1 = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            ret1, jpeg = cv2.imencode('.jpg', self.image1)
            if ret1:
                amr_latest_frame = jpeg.tobytes()
        except Exception as e:
            print(f"Error in image callback: {e}")
            self.image = None

    def create_table(self):
        """ 객체 탐지 정보 테이블 생성 """
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS detections (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    object_name TEXT,
                                    confidence REAL,
                                    x_center INTEGER,
                                    y_center INTEGER,
                                    width INTEGER,
                                    height INTEGER,
                                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                                )''')
            self.conn.commit()
        except sqlite3.Error as e:
            self.get_logger().error(f"Error creating table: {e}")

    def amr_listener_callback(self, msg):
        """ 객체 탐지 데이터를 받아오는 콜백 함수 """
        try:
            amr_detection_data = json.loads(msg.data)  # JSON 데이터를 파싱하여 객체 탐지 정보 추출
            self.get_logger().info(f"Received detection data: {amr_detection_data}")
            self.save_amr_detection_data(amr_detection_data)  # 데이터베이스에 저장
        except Exception as e:
            self.get_logger().error(f"Failed to process detection data: {e}")

    def save_amr_detection_data(self, amr_detection_data):
        """ 탐지된 객체 데이터를 SQLite3 데이터베이스에 저장 """
        try:
            with self.conn:
                cursor = self.conn.cursor()
                for data in amr_detection_data:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute('''INSERT INTO detections (object_name, confidence, x_center, y_center, width, height, timestamp)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)''', 
                                (data['object_name'], data['confidence'], data['x_center'], data['y_center'],
                                    data['width'], data['height'], timestamp))
        except sqlite3.Error as e:
            self.get_logger().error(f"Error saving detection data: {e}")
    def __del__(self):
        """ 객체가 파괴될 때 데이터베이스 연결 종료 """
        self.conn.close()

def generate_stream():
    global amr_latest_frame
    while True:
        if amr_latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + amr_latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
            
def main(args=None):
    rclpy.init(args=args)
    node = DetectionSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
