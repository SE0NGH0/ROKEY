import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
from ultralytics import YOLO
import cv2
import json
import numpy as np

class YoloDetectionNode(Node):
    def __init__(self):
        super().__init__('yolo_detection_node')
        self.publisher_ = self.create_publisher(Image, 'camera/image', 10)  # Image 메시지를 퍼블리시
        self.detection_publisher_ = self.create_publisher(String, 'camera/detections', 10)
        self.bridge = CvBridge()
        self.model = YOLO('best(2).pt')
        self.cap = cv2.VideoCapture(2)  # 웹캠 연결 (웹캠 2번 사용)

        self.timer = self.create_timer(0.05, self.process_frame)  # 0.1초마다 process_frame 호출

    def process_frame(self):
        red_screen = False
        coordinates = [(257, 55), (604, 107), (541, 361), (115, 265)]
        ret, frame = self.cap.read()  # 웹캠에서 프레임 읽기
        if not ret:
            self.get_logger().error("Failed to capture image")
            return
        
        results = self.model(frame)  # YOLO 모델로 객체 탐지
        detection_data = []

        # YOLO 모델이 탐지한 객체 정보 처리
        for result in results[0].boxes:
            x1, y1, x2, y2 = map(int, result.xyxy[0])  # 바운딩 박스 좌표
            confidence = result.conf[0]  # 신뢰도
            class_id = int(result.cls[0])  # 클래스 ID
            label = f"{self.model.names[class_id]} {confidence:.2f}"

            center_x = (x1 + x2) // 2 # 객체의 중심 좌표, 바운딩 박스 좌표를 이용해 계산
            center_y = (y1 + y2) // 2 # 후에 경계 박스를 넘어가는 기준이 되는 좌표

            detection_data.append({
                'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                'confidence': float(confidence), 'class_id': class_id
            })
            if len(coordinates) == 4: # 4개의 사각형 좌표가 모두 저장된 경우에만 활성화 되는 함수
                pts = np.array(coordinates, np.int32).reshape((-1, 1, 2)) # coordinates를 다각형 그리기에 필요한 형식으로 변환
                cv2.polylines(frame, [pts], isClosed=True, color=(0, 0, 255), thickness=2) # 4개의 좌표를 서로 이어서 초록색의 선으로 다각형을 그림
                if cv2.pointPolygonTest(pts, (center_x, center_y), False) > 0: # 객체 중심 좌표가 사각형 내부에 있는지 확인. 내부에 있다면 red_screen 변수를 True로 설정하여 화면 색을 빨간색으로 점등
                    red_screen = True  # 충돌이 발생하면 red_screen 활성화
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # 탐지된 객체 데이터를 JSON 형식으로 변환하여 퍼블리시
        try:
            detection_msg = String()
            detection_msg.data = json.dumps(detection_data)  # JSON 형식으로 변환
            self.detection_publisher_.publish(detection_msg)
        except Exception as e:
            self.get_logger().error(f"Failed to publish detection data: {e}")  
                  
        if red_screen: # red_screen 변수가 True가 되면 활성화 되는 함수
            overlay = frame.copy() # overlay 변수에 프레임을 카피하여 저장
            overlay[:] = (0, 0, 255)  # overlay변수에 저장된 프레임을 빨간색으로 설정
            alpha = 0.4  # 빨간색 overlay의 투명도를 설정
            frame = cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0) # 빨간색 overlay를 원본 frame위에 투명도에 따라 합성하여 표시

        # OpenCV 이미지를 ROS 이미지 메시지로 변환
        try:
            img_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")  # BGR 이미지 -> ROS Image 메시지 변환
            self.publisher_.publish(img_msg)  # 이미지 메시지 퍼블리시
            self.get_logger().info("Publishing image...")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")

    def __del__(self):
        self.cap.release()  # 웹캠 해제

def main(args=None):
    rclpy.init(args=args)  # ROS2 초기화
    node = YoloDetectionNode()  # 노드 생성
    rclpy.spin(node)  # 노드 실행
    node.destroy_node()  # 노드 종료
    rclpy.shutdown()  # ROS2 종료

if __name__ == '__main__':
    main()
