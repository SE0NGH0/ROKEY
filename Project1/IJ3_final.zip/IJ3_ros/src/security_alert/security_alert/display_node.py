import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
import cv2
import numpy as np
from cv_bridge import CvBridge
import json

class DisplayNode(Node):
    def __init__(self):
        super().__init__('display_node')
        self.image_subscription = self.create_subscription(
            Image,
            'camera/image',
            self.image_callback,
            10)
        self.detection_subscription = self.create_subscription(
            String, 
            'camera/detections',
            self.detection_callback,
            10)

        self.bridge = CvBridge()
        cv2.namedWindow('Camera')

    def image_callback(self, msg):
        try:
            # ROS 이미지 메시지를 OpenCV 이미지로 변환
            frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            cv2.imshow('Camera', frame)
            cv2.waitKey(1)
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")

    def detection_callback(self, msg):
        try:
            # 객체 탐지 데이터를 JSON 형식으로 파싱
            detection_data = json.loads(msg.data)
            self.get_logger().info(f"Detection data: {detection_data}")
        except Exception as e:
            self.get_logger().error(f"Failed to parse detection data: {e}")
    

def main(args=None):
    rclpy.init(args=args)
    node = DisplayNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


