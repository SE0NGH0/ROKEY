import cv2
import rclpy
import numpy as np
from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import sqlite3
import json

class DetectionSubscriberNode(Node):
    def __init__(self):
        super().__init__('detection_subscriber_node')
        self.bridge = CvBridge()
        self.image = None
    
        self.detection_sub = self.create_subscription(
            String,
            'camera/detections',  # 객체 탐지 정보를 퍼블리시하는 토픽
            self.listener_callback,  # 콜백 함수
            10
        )
        self.image_sub = self.create_subscription(
            Image,
            'camera/image',
            self.image_callback1,
            10
        )
        self.detection_sub  # 객체를 유지하여 구독을 활성화

        # SQLite3 데이터베이스 연결
        self.conn = sqlite3.connect('detection.db')  # 기존 데이터베이스 연결
        self.cursor = self.conn.cursor()
        self.create_table()

    def image_callback1(self, msg) :
        global latest_frame
        try:
            self.image1 = self.bridge.imgmsg_to_cv2(msg, "brg8")
            ret1, jpeg = cv2.imencode('.jpg', self.image1)
            if ret1:
                latest_frame = jpeg.tobytes()
        except Exception as e:
            print(f"Error in image callback: {e}")
            self.image = None

    def create_table(self):
        """ 테이블이 없으면 생성하는 함수 """
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS detections (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    x1 INTEGER,
                                    y1 INTEGER,
                                    x2 INTEGER,
                                    y2 INTEGER,
                                    confidence REAL,
                                    class_id INTEGER
                                )''')
            self.conn.commit()
        except sqlite3.Error as e:
            self.get_logger().error(f"Error creating table: {e}")

    def listener_callback(self, msg):
        """ 객체 탐지 데이터를 받아오는 콜백 함수 """
        try:
            detection_data = json.loads(msg.data)  # JSON 데이터를 파싱하여 객체 탐지 정보 추출
            self.get_logger().info(f"Received detection data: {detection_data}")
            self.save_detection_data(detection_data)  # 데이터베이스에 저장
        except Exception as e:
            self.get_logger().error(f"Failed to process detection data: {e}")

    def save_detection_data(self, detection_data):
        """ 탐지된 객체 데이터를 SQLite3 데이터베이스에 저장 """
        try:
            for data in detection_data:
                self.cursor.execute('''INSERT INTO detections (x1, y1, x2, y2, confidence, class_id)
                                       VALUES (?, ?, ?, ?, ?, ?)''', 
                                       (data['x1'], data['y1'], data['x2'], data['y2'], data['confidence'], data['class_id']))
            self.conn.commit()  # 변경 사항 커밋
        except sqlite3.Error as e:
            self.get_logger().error(f"Error saving detection data: {e}")

    def __del__(self):
        """ 객체가 파괴될 때 데이터베이스 연결 종료 """
        self.conn.close()

def generate_stream():
    global latest_frame
    while True:
        if latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
            
def main(args=None):
    rclpy.init(args=args)
    node = DetectionSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
