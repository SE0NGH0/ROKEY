from flask import Flask, render_template, Response, request, redirect, url_for, session, flash, jsonify
import cv2
import threading
import time
import rclpy
from std_msgs.msg import String, Bool
import json
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

app = Flask(__name__, template_folder='/home/moon0/IJ3_ros/templates')
app.secret_key = 'your_secret_key'  # 세션 관리를 위한 비밀 키

# 글로벌 변수로 ROS2 구독 노드에서 데이터를 가져오도록 설정
detection_data = []
amr_detection_data = []
latest_frame = None
amr_latest_frame = None
red_alert_status = False

USERNAME = 'ij3'
PASSWORD = 'pkm'

# 로그인 페이지 라우트
@app.route('/')
def home():
    # 로그인한 사용자가 있으면 환영 페이지로 리디렉션
    if 'username' in session:
        return redirect(url_for('welcome'))
    # 로그인 페이지 렌더링
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # 올바른 사용자 이름과 비밀번호 확인
        if username == USERNAME and password == PASSWORD:
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('welcome'))
        else:
            flash('Invalid username or password!', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')

# 환영 페이지 라우트 (로그인 필요)
@app.route('/welcome')
def welcome():
    # 로그인이 되어 있지 않으면 로그인 페이지로 리디렉션
    if 'username' not in session:
        flash('Please log in first!', 'warning')
        return redirect(url_for('login'))
    return render_template('image.html', username=session['username'])

# 로그아웃 라우트
@app.route('/logout', methods=['POST'])
def logout():
    # 세션에서 사용자 정보 제거 후 로그인 페이지로 이동
    session.pop('username', None)
    flash('Logged out successfully!', 'info')
    return redirect(url_for('login'))

@app.route('/detections')
def get_detections():
    global detection_data
    global amr_detection_data
    global red_alert_status

    # 데이터 확인을 위해 콘솔에 출력
    print('Detection data:', detection_data)
    print('AMR detection data:', amr_detection_data)
    print('Red_Alert_Status', red_alert_status)

    return jsonify(detection_data=detection_data, 
                           amr_detection_data=amr_detection_data, 
                           red_alert_status=red_alert_status)

@app.route('/video_feed')
def video_feed():
    """ 비디오 피드를 스트리밍하는 라우트 """
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed2')
def video_feed2():
    """ 비디오 피드를 스트리밍하는 라우트 """
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream2(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/app')
def app_page():
    # 로그인 검증을 포함하고 싶다면 아래 조건을 추가
    if 'username' not in session:
        flash('Please log in first!', 'warning')
        return redirect(url_for('login'))
    return render_template('app.html')

def generate_stream():
    """ 최신 프레임을 반복적으로 스트리밍하는 제너레이터 함수 """
    global latest_frame
    while True:
        if latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
        time.sleep(0.1)  # 프레임 업데이트 간격 설정

def generate_stream2():
    """ 최신 프레임을 반복적으로 스트리밍하는 제너레이터 함수 """
    global amr_latest_frame
    while True:
        if amr_latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + amr_latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
        time.sleep(0.1)  # 프레임 업데이트 간격 설정

def ros2_listener_thread():
    # ROS2 초기화 및 구독 설정
    rclpy.init()
    node = rclpy.create_node('flask_listener')

    def detection_callback(msg):
        global detection_data
        detection_data = json.loads(msg.data)

    def image_callback(msg):
        global latest_frame
        try:
            # 최신 이미지 프레임을 저장
            bridge = CvBridge()
            image = bridge.imgmsg_to_cv2(msg, "bgr8")
            ret, jpeg = cv2.imencode('.jpg', image)
            if ret:
                latest_frame = jpeg.tobytes()
        except Exception as e:
            print(f"Error in image callback: {e}")

    def amr_detection_callback(msg):
        global amr_detection_data
        amr_detection_data = json.loads(msg.data)

    def amr_image_callback(msg):
        global amr_latest_frame
        try:
            # 최신 이미지 프레임을 저장
            bridge = CvBridge()
            image2 = bridge.imgmsg_to_cv2(msg, "bgr8")
            ret2, jpeg = cv2.imencode('.jpg', image2)
            if ret2:
                amr_latest_frame = jpeg.tobytes()
        except Exception as e:
            print(f"Error in image callback: {e}")

    def red_alert_callback(msg):
        global red_alert_status
        # red_alert_status 업데이트
        red_alert_status = msg.data
        print(f"Red Alert Status Updated: {red_alert_status}")

    # ROS2 토픽 구독 설정
    node.create_subscription(String, 'camera/detections', detection_callback, 10)
    node.create_subscription(Image, 'camera/image', image_callback, 10)
    node.create_subscription(String, 'amr/detections', amr_detection_callback, 10)
    node.create_subscription(Image, 'amr/image', amr_image_callback, 10)
    node.create_subscription(Bool, 'amr/red_alert', red_alert_callback, 10)

    # ROS2 스핀(구독 활성화)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

def main():
    # ROS2 구독 노드를 별도 스레드에서 실행
    ros2_thread = threading.Thread(target=ros2_listener_thread)
    ros2_thread.start()

    # Flask 서버 실행
    app.run(host='0.0.0.0', port=5000)

if __name__ == '__main__':
    main()
