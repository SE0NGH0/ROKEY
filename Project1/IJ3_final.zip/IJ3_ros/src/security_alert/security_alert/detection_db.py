import sqlite3

# SQLite3 데이터베이스 연결
conn = sqlite3.connect('detection.db')
cursor = conn.cursor()

# 객체 탐지 결과를 저장할 테이블 생성
cursor.execute('''
CREATE TABLE IF NOT EXISTS detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    object_name TEXT,
    confidence REAL,
    x_center INTEGER,
    y_center INTEGER,
    width INTEGER,
    height INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
''')

# 데이터베이스 커밋 및 연결 종료
conn.commit()
conn.close()

print("Database initialized successfully.")
