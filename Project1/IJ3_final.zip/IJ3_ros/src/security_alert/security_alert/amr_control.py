import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
from ultralytics import YOLO
import cv2
import json
import sqlite3
from datetime import datetime

class YoloDetectionNode(Node):
    def __init__(self):
        super().__init__('amr_detection_node')
        self.image_publisher_ = self.create_publisher(Image, 'amr/image', 10)
        self.detection_publisher_ = self.create_publisher(String, 'amr/detections', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.bridge = CvBridge()
        self.model = YOLO('best.pt')
        self.cap = cv2.VideoCapture(0)
        self.timer = self.create_timer(0.05, self.process_frame)

        # SQLite3 데이터베이스 연결
        self.conn = sqlite3.connect('/home/rokey2/amr_ros/src/amr_camera/amr_camera/amr_detection.db')
        self.cursor = self.conn.cursor()
        self.create_table()

        self.is_tracking = False
        self.current_detection = None
        self.image_shape = None

    def create_table(self):
        """ 객체 탐지 정보 테이블 생성 """
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS detections (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    object_name TEXT,
                                    confidence REAL,
                                    x_center INTEGER,
                                    y_center INTEGER,
                                    width INTEGER,
                                    height INTEGER,
                                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                                )''')
            self.conn.commit()
        except sqlite3.Error as e:
            self.get_logger().error(f"Error creating table: {e}")

    def save_detection_data(self, amr_detection_data):
        """ 탐지된 객체 데이터를 SQLite3 데이터베이스에 저장 """
        try:
            with self.conn:
                cursor = self.conn.cursor()
                for data in amr_detection_data:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute('''INSERT INTO detections (object_name, confidence, x_center, y_center, width, height, timestamp)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)''',
                                (data['object_name'], data['confidence'], data['x_center'], data['y_center'],
                                    data['width'], data['height'], timestamp))
        except sqlite3.Error as e:
            self.get_logger().error(f"Error saving detection data: {e}")

    def process_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().error("Failed to capture image")
            return

        results = self.model(frame)
        amr_detection_data = []

        for result in results[0].boxes:
            x1, y1, x2, y2 = map(int, result.xyxy[0])
            confidence = float(result.conf[0])
            class_id = int(result.cls[0])
            label = self.model.names[class_id]
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            width = x2 - x1
            height = y2 - y1

            amr_detection_data.append({
                'object_name': label,
                'confidence': confidence,
                'x_center': center_x,
                'y_center': center_y,
                'width': width,
                'height': height,
                'timestamp': timestamp
            })

            # 바운딩 박스와 레이블 그리기
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{label} {confidence:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            if label == 'RCcar':
                self.get_logger().info(f"Target object detected: {label}")
                self.is_tracking = True
                self.current_detection = result
                self.image_shape = frame.shape
                break

        self.save_detection_data(amr_detection_data)

        try:
            detection_msg = String()
            detection_msg.data = json.dumps(amr_detection_data)
            self.detection_publisher_.publish(detection_msg)
        except Exception as e:
            self.get_logger().error(f"Failed to publish detection data: {e}")

        try:
            img_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.image_publisher_.publish(img_msg)
            self.get_logger().info("Publishing image...")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")

        if self.is_tracking:
            self.track_object()

    def track_object(self):
        if not self.current_detection or not self.image_shape:
            return

        self.get_logger().info("Tracking the object...")
        twist = Twist()

        x_center = float((self.current_detection.xyxy[0][0] + self.current_detection.xyxy[0][2]) / 2.0)
        y_center = float((self.current_detection.xyxy[0][1] + self.current_detection.xyxy[0][3]) / 2.0)
        image_center_x = float(self.image_shape[1] / 2.0)
        image_center_y = float(self.image_shape[0] / 2.0)

        error_x = float(x_center - image_center_x)
        error_y = float(y_center - image_center_y)

        # 오차 허용 범위를 늘려 로봇이 흔들리지 않도록 설정
        tolerance_x = 10
        tolerance_y = 0

        # 좌우 회전 제어
        if abs(error_x) > tolerance_x:
            twist.angular.z = float(-0.001 * error_x) * (abs(error_x) / image_center_x)  # 오류가 줄어들수록 속도를 줄이도록 설정

        else:
            twist.angular.z = 0.0

        # 전진 제어
        if abs(error_y) > tolerance_y:
            twist.linear.x = float(0.001 * (image_center_y - y_center))
        else:
            twist.linear.x = 0.0

        # 속도 명령 퍼블리시
        self.cmd_vel_pub.publish(twist)

        # 목표 중심에 도달하면 멈춤
        if abs(error_x) <= tolerance_x and abs(error_y) <= tolerance_y:
            self.is_tracking = False
            self.current_detection = None

    def __del__(self):
        self.cap.release()
        self.conn.close()

def main(args=None):
    rclpy.init(args=args)
    node = YoloDetectionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()