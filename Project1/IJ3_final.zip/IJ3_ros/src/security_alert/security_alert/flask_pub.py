import rclpy  # ROS2를 파이썬 코드로 사용할 수 있도록 해주는 모듈
from rclpy.node import Node # 노드 생성을 위한 모듈
from sensor_msgs.msg import Image # ROS2에서 사용하는 Image 메시지 타입을 사용하기 위한 모듈
from std_msgs.msg import String # JSON 형식으로 변환된 객체 정보를 퍼블리시하기 위해 String 메세지 타입 사용
from cv_bridge import CvBridge # OpenCV 이미지와 ROS2 Image 메세지 타입 간의 변환을 위한 모듈
from ultralytics import YOLO # YOLOv8 모델을 사용해 객체를 탐지하기 위한 모듈
import cv2 # OpenCV를 사용하기 위한 모듈
import json # 객체 정보를 JSON 타입으로 변환하기 위한 모듈
import numpy as np # 수학 연산을 위한 모듈
import sqlite3  # SQLite3를 사용하여 데이터베이스 작업을 위한 모듈

class YoloDetectionNode(Node):
    def __init__(self):
        super().__init__('yolo_detection_node') # 부모 클래스인 Node를 참조하여 'yolo_detection_node'라는 이름으로 노드를 사용
        self.publisher_ = self.create_publisher(Image, 'camera/image', 10)  # 카메라 이미지 프레임을 퍼블리시할 Image 타입의 ROS2 퍼블리셔 생성
        self.detection_publisher_ = self.create_publisher(String, 'camera/detections', 10) # 탐지된 객체 정보를 JSON 형식으로 퍼블리시할 String 타입의 ROS2 퍼블리셔 생성
        self.bridge = CvBridge() # OpenCV 이미지와 ROS2 Image 메시지 타입 변환을 위한 CvBridge 인스턴스.
        self.model = YOLO('best(2).pt') # YOLOv8의 미리 학습된 모델을 사용
        self.cap = cv2.VideoCapture(0)  # 웹캠 연결 (웹캠 2번 사용)
        self.timer = self.create_timer(0.05, self.process_frame)  # 0.05초마다 process_frame 호출

        # SQLite3 데이터베이스 연결
        self.conn = sqlite3.connect('object_detection.db')  # 데이터베이스 파일 연결
        self.cursor = self.conn.cursor()
        self.create_table()  # 테이블 생성

    def create_table(self):
        """ 객체 탐지 정보 테이블 생성 """
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS detections (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    x1 INTEGER,
                                    y1 INTEGER,
                                    x2 INTEGER,
                                    y2 INTEGER,
                                    confidence REAL,
                                    class_id INTEGER
                                )''')
            self.conn.commit()
        except sqlite3.Error as e:
            self.get_logger().error(f"Error creating table: {e}")

    def save_detection_data(self, detection_data):
        """ 탐지된 객체 데이터를 SQLite3 데이터베이스에 저장 """
        try:
            for data in detection_data:
                self.cursor.execute('''INSERT INTO detections (x1, y1, x2, y2, confidence, class_id)
                                       VALUES (?, ?, ?, ?, ?, ?)''', 
                                       (data['x1'], data['y1'], data['x2'], data['y2'], data['confidence'], data['class_id']))
            self.conn.commit()  # 변경 사항 커밋
        except sqlite3.Error as e:
            self.get_logger().error(f"Error saving detection data: {e}")

    def process_frame(self):
        red_screen = False #  후에 객체가 경계 구역 안으로 들어왔을 때, 경고를 표시하기 위한 변수
        coordinates = [(257, 55), (604, 107), (541, 361), (115, 265)] # 사각형의 꼭짓점이 되는 리스트로 경계 구역을 설정하기 위해 사용되는 값
        ret, frame = self.cap.read()  # 웹캠에서 프레임 읽기 ,ret은 프레임을 읽어들이는 것의 성공 여부를 확인하는 변수
        if not ret: # 프레임을 읽어오지 못했을 때 실행되는 조건문
            self.get_logger().error("Failed to capture image") # 로그를 띄워 이미지 프레임을 불러오지 못했다는 문구 출력
            return
        
        results = self.model(frame)  # YOLO 모델로 객체 탐지
        detection_data = [] # 객체 탐지 데이터를 담을 빈 리스트
        
        # YOLO 모델이 탐지한 객체 정보 처리
        for result in results[0].boxes: 
            x1, y1, x2, y2 = map(int, result.xyxy[0])  # 바운딩 박스 좌표
            confidence = result.conf[0]  # 신뢰도
            class_id = int(result.cls[0])  # 클래스 ID
            label = f"{self.model.names[class_id]} {confidence:.2f}" # 탐지된 객체의 클래스 이름과 신뢰도

            center_x = (x1 + x2) // 2 # 객체의 중심 좌표, 바운딩 박스 좌표를 이용해 계산
            center_y = (y1 + y2) // 2 # 후에 경계 박스를 넘어가는 기준이 되는 좌표

            detection_data.append({ # 탐지된 객체 정보를 detection_data 리스트에 딕셔너리 형식으로 추가.
                'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                'confidence': float(confidence), 'class_id': class_id
            })
            if len(coordinates) == 4: # 4개의 사각형 좌표가 모두 저장된 경우에만 활성화 되는 함수
                pts = np.array(coordinates, np.int32).reshape((-1, 1, 2)) # coordinates를 다각형 그리기에 필요한 형식으로 변환
                cv2.polylines(frame, [pts], isClosed=True, color=(0, 0, 255), thickness=2) # 4개의 좌표를 서로 이어서 초록색의 선으로 다각형을 그림
                if cv2.pointPolygonTest(pts, (center_x, center_y), False) > 0: # 객체 중심 좌표가 사각형 내부에 있는지 확인. 내부에 있다면 red_screen 변수를 True로 설정하여 화면 색을 빨간색으로 점등
                    red_screen = True  # 충돌이 발생하면 red_screen 활성화
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2) # 탐지된 객체의 바운딩 박스를 그리는 코드
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2) # 탐지된 객체의 바운딩 박스에 텍스트를 입력하는 코드
            
        # 탐지된 객체 데이터를 SQLite3에 저장
        self.save_detection_data(detection_data)

        # 탐지된 객체 데이터를 JSON 형식으로 변환하여 퍼블리시
        try:
            detection_msg = String() # 탐지 객체의 정보를 String 메세지 타입의 인스턴스로 생성
            detection_msg.data = json.dumps(detection_data)  # 앞서 탐지 객체 정보를 담은 리스트를 JSON 형식으로 변환, 이를 통해 데이터를 직렬화.
            self.detection_publisher_.publish(detection_msg) # 탐지 객체 데이터를 퍼블리시
        except Exception as e:
            self.get_logger().error(f"Failed to publish detection data: {e}")  # 만약 detection_msg를 JSON으로 변환하거나 퍼블리시하는 과정에서 오류가 발생한다면, 예외(Exception)가 발생하고 이 블록으로 이동하게 됩니다.
                  
        if red_screen: # red_screen 변수가 True가 되면 활성화 되는 함수
            overlay = frame.copy() # overlay 변수에 프레임을 카피하여 저장
            overlay[:] = (0, 0, 255)  # overlay변수에 저장된 프레임을 빨간색으로 설정
            alpha = 0.4  # 빨간색 overlay의 투명도를 설정
            frame = cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0) # 빨간색 overlay를 원본 frame위에 투명도에 따라 합성하여 표시

        # OpenCV 이미지를 ROS 이미지 메시지로 변환
        try:
            img_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")  # BGR 이미지 -> ROS Image 메시지 변환
            self.publisher_.publish(img_msg)  # 이미지 메시지 퍼블리시
            self.get_logger().info("Publishing image...")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")

    def __del__(self):
        self.cap.release()  # 웹캠 해제

def main(args=None):
    rclpy.init(args=args)  # ROS2 초기화
    node = YoloDetectionNode()  # 노드 생성
    rclpy.spin(node)  # 노드 실행
    node.destroy_node()  # 노드 종료
    rclpy.shutdown()  # ROS2 종료

if __name__ == '__main__':
    main()