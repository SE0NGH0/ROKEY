import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')
        self.publisher_ = self.create_publisher(Image, 'camera/image', 10)
        self.timer = self.create_timer(0.1, self.timer_callback)  # 0.1초마다 콜백 호출
        self.bridge = CvBridge()

    def timer_callback(self):
        # 카메라에서 이미지를 읽어오기
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()

        if not ret:
            self.get_logger().error('Failed to capture image')
            return
        
        # OpenCV 이미지를 ROS 이미지 메시지로 변환
        try:
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.publisher_.publish(msg)  # 이미지 메시지 발행
            self.get_logger().info('Publishing image...')
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")
        
        cap.release()

def main(args=None):
    rclpy.init(args=args)
    image_publisher = ImagePublisher()
    rclpy.spin(image_publisher)
    image_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()