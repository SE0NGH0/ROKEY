from flask import Flask, render_template, Response, request, redirect, url_for, session, flash, jsonify
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import threading
import json
from std_msgs.msg import String

app = Flask(__name__, template_folder="/home/moon0/IJ3_ros/templates")
app.secret_key = 'your_secret_key'  # 세션 관리를 위한 비밀 키

detection_data = []

# 전역 변수로 최신 프레임 저장
latest_frame = None
latest_frame2 = None

# 로그인에 사용할 하드코딩된 사용자 이름과 비밀번호
USERNAME = 'ij3'
PASSWORD = 'pkm'

class ROSSubscriber(Node):
    def __init__(self):
        super().__init__('ros_subscriber')
        self.bridge = CvBridge()
        self.image = None
        # ROS2 구독자 설정
        self.subscription1 = self.create_subscription(
            Image, 
            'camera/image', 
            self.image_callback1, 
            10
        )
        self.subscription2 = self.create_subscription(
            Image, 
            'camera/image2', 
            self.image_callback2, 
            10
        )
        self.detection_sub = self.create_subscription(
            String, 
            'camera/detections', 
            self.detection_callback, 
            10
        )
    def image_callback1(self, msg):
        global latest_frame
        try:
            # ROS2 메시지를 OpenCV 이미지로 변환
            self.image1 = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # 이미지를 JPEG로 인코딩하여 latest_frame에 저장
            ret1, jpeg = cv2.imencode('.jpg', self.image1)
            if ret1:
                latest_frame = jpeg.tobytes()  # Flask에서 사용할 이미지 데이터
        except Exception as e:
            print(f"Error in image callback: {e}")
            self.image = None

    def image_callback2(self, msg):
        global latest_frame2
        try:
            # ROS2 메시지를 OpenCV 이미지로 변환
            self.image2 = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # 이미지를 JPEG로 인코딩하여 latest_frame2에 저장
            ret2, jpeg = cv2.imencode('.jpg', self.image2)
            if ret2:
                latest_frame2 = jpeg.tobytes()  # 두 번째 카메라 이미지 데이터
        except Exception as e:
            print(f"Error in image callback2: {e}")
            self.image2 = None
    def detection_callback(self, msg):
        global detection_data
        self.detection_data = json.loads(msg.data)
        self.get_logger().info(f"Received detection data: {detection_data}")

# 비디오 스트림 생성기 (웹 페이지에 스트리밍할 프레임 제공)
def generate_stream():
    global latest_frame
    while True:
        if latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')

# 두 번째 카메라 비디오 스트림 생성기
def generate_stream2():
    global latest_frame2
    while True:
        if latest_frame2:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame2 + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')

def ros2_listener_thread():

    # ROS2 초기화 및 구독 설정
    rclpy.init()
    node = rclpy.create_node('flask_detection_listener')

    def callback(msg):
        global detection_data
        detection_data = json.loads(msg.data)

    node.create_subscription(String, 'camera/detections', callback, 10)

    # ROS2 스핀(구독 활성화)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


# ROS2 노드 클래스
class MyRosNode(Node):
    def __init__(self):
        super().__init__('my_ros_node')
        self.get_logger().info("ROS2 Node has been started.")

# 로그인 페이지 라우트
@app.route('/')
def home():
    # 로그인한 사용자가 있으면 환영 페이지로 리디렉션
    if 'username' in session:
        return redirect(url_for('welcome'))
    # 로그인 페이지 렌더링
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # 올바른 사용자 이름과 비밀번호 확인
        if username == USERNAME and password == PASSWORD:
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('welcome'))
        else:
            flash('Invalid username or password!', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')

# 환영 페이지 라우트 (로그인 필요)
@app.route('/welcome')
def welcome():
    # 로그인이 되어 있지 않으면 로그인 페이지로 리디렉션
    if 'username' not in session:
        flash('Please log in first!', 'warning')
        return redirect(url_for('login'))
    return render_template('camera.html', username=session['username'])

# 로그아웃 라우트
@app.route('/logout', methods=['POST'])
def logout():
    # 세션에서 사용자 정보 제거 후 로그인 페이지로 이동
    session.pop('username', None)
    flash('Logged out successfully!', 'info')
    return redirect(url_for('login'))

# 비디오 피드를 위한 라우트
@app.route('/video_feed')
def video_feed():
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

# 두 번째 카메라 비디오 피드를 위한 라우트
@app.route('/video_feed2')
def video_feed2():
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream2(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/app')
def app_page():
    # 로그인 검증을 포함하고 싶다면 아래 조건을 추가
    if 'username' not in session:
        flash('Please log in first!', 'warning')
        return redirect(url_for('login'))
    return render_template('app.html')

@app.route('/detections')
def get_detections():
    global detection_data
    return jsonify(detection_data)
       
# ROS2 노드와 웹 서버를 함께 실행
def start_ros_node():
    try:
        rclpy.init()
        node = MyRosNode()
        ros_node = ROSSubscriber()  # ROS2 노드 생성
        rclpy.spin(ros_node)  # ROS2 노드 실행
        rclpy.spin(node)
        rclpy.shutdown()
    except Exception as e:
        print(f"Error in ROS node: {e}")

def main():
    ros_thread = threading.Thread(target=start_ros_node)
    ros_thread.start()

    # Flask 웹 서버 실행
    app.run(host='0.0.0.0', port=5000)

if __name__ == '__main__':
    main()
