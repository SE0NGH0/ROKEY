import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json

class DetectionSubscriberNode(Node):
    def __init__(self):
        super().__init__('detection_subscriber')
        self.subscription = self.create_subscription(
            String,
            'camera/detections',
            self.detection_callback,
            10
        )
        self.detection_data = []

    def detection_callback(self, msg):
        # 수신된 JSON 문자열을 파싱하여 detection_data에 저장
        self.detection_data = json.loads(msg.data)
        self.get_logger().info(f"Received detection data: {self.detection_data}")

def main(args=None):
    rclpy.init(args=args)
    node = DetectionSubscriberNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()