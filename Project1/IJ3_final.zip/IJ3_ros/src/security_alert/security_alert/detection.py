import rclpy
from rclpy.node import Node
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from ultralytics import YOLO

class YOLOWebcamNode(Node):
    def __init__(self):
        super().__init__('yolo_webcam_node')
        # YOLO 모델 초기화
        self.model = YOLO('best(2).pt')
        # 웹캠 초기화
        self.cap = cv2.VideoCapture(2)
        # ROS2 퍼블리셔 설정
        self.image_pub = self.create_publisher(Image, 'yolo_detected_image', 10)
        # CvBridge 초기화 (OpenCV 이미지를 ROS 이미지 메시지로 변환)
        self.bridge = CvBridge()
        # 타이머 설정 (0.1초 간격으로 프레임 업데이트)
        self.timer = self.create_timer(0.1, self.update_frame)
    def update_frame(self):
        ret, frame = self.cap.read()
        if ret:
            # YOLO로 프레임 처리
            results = self.model(frame)
            # 객체 감지 결과를 프레임에 표시
            for result in results[0].boxes:
                x1, y1, x2, y2 = map(int, result.xyxy[0])
                confidence = result.conf[0]
                class_id = int(result.cls[0])
                label = f"{self.model.names[class_id]} {confidence:.2f}"
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            # OpenCV 이미지를 ROS2 이미지 메시지로 변환하여 퍼블리시
            ros_image = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.image_pub.publish(ros_image)
    def destroy_node(self):
        # 노드 종료 시 웹캠 해제
        self.cap.release()
        super().destroy_node()
def main(args=None):
    rclpy.init(args=args)
    node = YOLOWebcamNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
if __name__ == '__main__':
    main()