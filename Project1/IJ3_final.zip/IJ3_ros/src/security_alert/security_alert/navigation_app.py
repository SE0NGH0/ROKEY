#!/usr/bin/env python3
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool

class NavigatorApp(Node):
    def __init__(self):
        super().__init__('navigator_node')
        self.navigator = BasicNavigator()
        
        # red_screen 구독 설정
        self.red_alert_subscriber = self.create_subscription(
            Bool,
            'amr/red_alert',
            self.red_alert_callback,
            10
        )
        
        self.red_alert_triggered = False
        self.set_initial_pose()

    def set_initial_pose(self):
        # 고정된 초기 위치 설정
        initial_pose = PoseStamped()
        initial_pose.header.frame_id = 'map'
        initial_pose.header.stamp = self.navigator.get_clock().now().to_msg()
        initial_pose.pose.position.x = 0.0
        initial_pose.pose.position.y = 0.0
        initial_pose.pose.orientation.w = 1.0
        self.navigator.setInitialPose(initial_pose)
        self.navigator.waitUntilNav2Active()

    def set_goal_location(self):
        # 목표 위치 설정 후 자율 주행 시작
        x, y = 2.0, 2.0  # 목표 위치 설정
        self.go_to_pose(x, y)

    def red_alert_callback(self, msg):
        # red_screen 신호 수신 시 동작
        if msg.data and not self.red_alert_triggered:
            self.get_logger().info("Red alert received, initiating navigation to goal.")
            self.red_alert_triggered = True
            # 목표 위치로 이동
            self.set_goal_location()

    def go_to_pose(self, x, y):
        # 목표 위치로 이동
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.navigator.get_clock().now().to_msg()
        goal_pose.pose.position.x = x
        goal_pose.pose.position.y = y
        goal_pose.pose.orientation.w = 1.0
        
        self.navigator.goToPose(goal_pose)

        # 이동이 완료될 때까지 기다리기
        while not self.navigator.isTaskComplete():
            pass

        result = self.navigator.getResult()
        if result == TaskResult.SUCCEEDED:
            self.get_logger().info('Goal succeeded!')
        elif result == TaskResult.CANCELED:
            self.get_logger().info('Goal was canceled!')
        elif result == TaskResult.FAILED:
            self.get_logger().info('Goal failed!')
        else:
            self.get_logger().info('Goal has an invalid return status!')

    def exiting(self):
        # Nav2 종료
        self.navigator.lifecycleShutdown()


def start_app():
    rclpy.init()
    app = NavigatorApp()
    app.exiting()
    rclpy.shutdown()


if __name__ == '__main__':
    start_app()
