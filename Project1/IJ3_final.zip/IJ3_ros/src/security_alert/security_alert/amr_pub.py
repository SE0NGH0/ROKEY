import rclpy  # ROS2를 파이썬 코드로 사용할 수 있도록 해주는 모듈
from rclpy.node import Node  # 노드 생성을 위한 모듈
from sensor_msgs.msg import Image  # ROS2에서 사용하는 Image 메시지 타입을 사용하기 위한 모듈
from std_msgs.msg import String  # JSON 형식으로 변환된 객체 정보를 퍼블리시하기 위해 String 메세지 타입 사용
from cv_bridge import CvBridge  # OpenCV 이미지와 ROS2 Image 메시지 타입 간의 변환을 위한 모듈
from ultralytics import YOLO  # YOLOv8 모델을 사용해 객체를 탐지하기 위한 모듈
import cv2  # OpenCV를 사용하기 위한 모듈
import json  # 객체 정보를 JSON 타입으로 변환하기 위한 모듈
import numpy as np  # 수학 연산을 위한 모듈
import sqlite3  # SQLite3를 사용하여 데이터베이스 작업을 위한 모듈
from datetime import datetime  # datetime 모듈을 사용하여 타임스탬프를 추가

class YoloDetectionNode(Node):
    def __init__(self):
        super().__init__('amr_detection_node')
        self.image_publisher_ = self.create_publisher(Image, 'amr/image', 10)
        self.detection_publisher_ = self.create_publisher(String, 'amr/detections', 10)
        self.bridge = CvBridge()
        self.model = YOLO('best.pt')  # YOLO 모델 로드
        self.cap = cv2.VideoCapture(2)  # 웹캠 연결
        self.timer = self.create_timer(0.05, self.process_frame)  # 0.05초마다 프레임 처리

        # SQLite3 데이터베이스 연결
        self.conn = sqlite3.connect('/home/moon0/IJ3_ros/src/security_alert/security_alert/amr_detection.db')  # 절대 경로 사용
        self.cursor = self.conn.cursor()
        self.create_table()  # 테이블 생성

    def create_table(self):
        """ 객체 탐지 정보 테이블 생성 """
        try:
            self.cursor.execute('''CREATE TABLE IF NOT EXISTS detections (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    object_name TEXT,
                                    confidence REAL,
                                    x_center INTEGER,
                                    y_center INTEGER,
                                    width INTEGER,
                                    height INTEGER,
                                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                                )''')
            self.conn.commit()
        except sqlite3.Error as e:
            self.get_logger().error(f"Error creating table: {e}")

    def save_detection_data(self, amr_detection_data):
        """ 탐지된 객체 데이터를 SQLite3 데이터베이스에 저장 """
        try:
            with self.conn:
                cursor = self.conn.cursor()
                for data in amr_detection_data:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute('''INSERT INTO detections (object_name, confidence, x_center, y_center, width, height, timestamp)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)''', 
                                (data['object_name'], data['confidence'], data['x_center'], data['y_center'],
                                    data['width'], data['height'], timestamp))
        except sqlite3.Error as e:
            self.get_logger().error(f"Error saving detection data: {e}")


    def process_frame(self):

        ret, frame = self.cap.read()  # 웹캠에서 프레임 읽기
        if not ret:
            self.get_logger().error("Failed to capture image")
            return
        
        results = self.model(frame)  # YOLO 모델로 객체 탐지
        amr_detection_data = []  # 객체 탐지 데이터를 저장할 리스트
        
        # YOLO 모델이 탐지한 객체 정보 처리
        for result in results[0].boxes: 
            x1, y1, x2, y2 = map(int, result.xyxy[0])  # 바운딩 박스 좌표
            confidence = result.conf[0]  # 신뢰도
            class_id = int(result.cls[0])  # 클래스 ID
            label = self.model.names[class_id]  # 객체 이름만 저장하도록 변경
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            width = x2 - x1
            height = y2 - y1

            amr_detection_data.append({
                'object_name': label,
                'confidence': float(confidence),
                'x_center': center_x,
                'y_center': center_y,
                'width': width,
                'height': height,
                'timestamp': timestamp
            })

            # 바운딩 박스와 레이블 그리기
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"{label} {confidence:.2f}", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # 탐지된 객체 데이터를 SQLite3에 저장
        self.save_detection_data(amr_detection_data)

        # 탐지된 객체 정보를 JSON 형식으로 퍼블리시
        try:
            detection_msg = String()
            detection_msg.data = json.dumps(amr_detection_data)  # JSON 형식으로 변환
            self.detection_publisher_.publish(detection_msg)
        except Exception as e:
            self.get_logger().error(f"Failed to publish detection data: {e}")


        # OpenCV 이미지를 ROS 이미지 메시지로 변환
        try:
            img_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            self.image_publisher_.publish(img_msg)
            self.get_logger().info("Publishing image...")
        except Exception as e:
            self.get_logger().error(f"Failed to convert image: {e}")

    def __del__(self):
        self.cap.release()  # 웹캠 해제
        self.conn.close()  # 데이터베이스 연결 종료

def main(args=None):
    rclpy.init(args=args)
    node = YoloDetectionNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
