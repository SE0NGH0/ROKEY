from flask import Flask, render_template, Response, request, redirect, url_for, session, flash
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import threading

app = Flask(__name__, template_folder='/home/moon0/IJ3_ros/templates')
app.secret_key = 'your_secret_key'  # 세션 관리에 필요한 비밀 키

# 전역 변수로 최신 프레임 저장
latest_frame = None
latest_frame2 = None

class ROSSubscriber(Node):
    def __init__(self):
        super().__init__('ros_subscriber')
        self.bridge = CvBridge()
        self.image = None
        # ROS2 구독자 설정
        self.subscription1 = self.create_subscription(
            Image, 
            'camera/image', 
            self.image_callback1, 
            10
        )
        self.subscription2 = self.create_subscription(
            Image, 
            'camera/image2', 
            self.image_callback2, 
            10
        )
    
    def image_callback1(self, msg):
        global latest_frame
        try:
            # ROS2 메시지를 OpenCV 이미지로 변환
            self.image1 = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # 이미지를 JPEG로 인코딩하여 latest_frame에 저장
            ret1, jpeg = cv2.imencode('.jpg', self.image1)
            if ret1:
                latest_frame = jpeg.tobytes()  # Flask에서 사용할 이미지 데이터
        except Exception as e:
            print(f"Error in image callback: {e}")
            self.image = None

    def image_callback2(self, msg):
        global latest_frame2
        try:
            # ROS2 메시지를 OpenCV 이미지로 변환
            self.image2 = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # 이미지를 JPEG로 인코딩하여 latest_frame2에 저장
            ret2, jpeg = cv2.imencode('.jpg', self.image2)
            if ret2:
                latest_frame2 = jpeg.tobytes()  # 두 번째 카메라 이미지 데이터
        except Exception as e:
            print(f"Error in image callback2: {e}")
            self.image2 = None

# 비디오 스트림 생성기 (웹 페이지에 스트리밍할 프레임 제공)
def generate_stream():
    global latest_frame
    while True:
        if latest_frame:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')

# 두 번째 카메라 비디오 스트림 생성기
def generate_stream2():
    global latest_frame2
    while True:
        if latest_frame2:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + latest_frame2 + b'\r\n')
        else:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + b'\r\n')
                        
# 로그인 페이지 라우트
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'password': 
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password!', 'danger')
            return redirect(url_for('login'))
    
    # Display login page for GET requests
    # return render_template('login.html')
    return render_template('login.html')

# 로그아웃 라우트
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out successfully!', 'info')
    return redirect(url_for('login'))

# 메인 페이지 (로그인 시 접근 가능)
@app.route('/')
def index():
    if 'username' not in session:  # 로그인되지 않은 경우 로그인 페이지로 리다이렉트
        flash('Please log in first!', 'warning')
        return redirect(url_for('login'))
    return render_template('index.html')  # 웹 페이지 HTML 렌더링

# 비디오 피드를 위한 라우트
@app.route('/video_feed')
def video_feed():
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

# 두 번째 카메라 비디오 피드를 위한 라우트
@app.route('/video_feed2')
def video_feed2():
    if 'username' not in session:  # 로그인되지 않은 경우 접근 차단
        return redirect(url_for('login'))
    return Response(generate_stream2(), mimetype='multipart/x-mixed-replace; boundary=frame')

# 웹 서버와 ROS2 노드를 동시에 실행하는 함수
def start_ros():
    try:
        rclpy.init()
        ros_node = ROSSubscriber()  # ROS2 노드 생성
        rclpy.spin(ros_node)  # ROS2 노드 실행
    except Exception as e:
        print(f"Error in ROS node: {e}")

def main(args=None):
    try:
        # ROS2 노드를 별도의 스레드로 실행
        ros_thread = threading.Thread(target=start_ros)
        ros_thread.start()

        # Flask 웹 서버 실행
        app.run(host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        print(f"Error in main function: {e}")

if __name__ == '__main__':
    main()  # 메인 함수 실행
